package com.godly.island.core

import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.godly.island.R

/** The app font (iCiel Samsung Sharp Sans Bold). Every weight maps to the same file so nothing is faux-bolded. */
val GodlyFont = FontFamily(
    Font(R.font.samsung_sharp_sans_bold, FontWeight.Normal),
    Font(R.font.samsung_sharp_sans_bold, FontWeight.Medium),
    Font(R.font.samsung_sharp_sans_bold, FontWeight.SemiBold),
    Font(R.font.samsung_sharp_sans_bold, FontWeight.Bold),
    Font(R.font.samsung_sharp_sans_bold, FontWeight.ExtraBold),
)
