package com.godly.island.media

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import androidx.compose.ui.graphics.Color
import com.godly.island.core.ErrorLog
import com.godly.island.events.ActionKind
import com.godly.island.events.IslandAction
import com.godly.island.events.IslandEvent
import com.godly.island.events.IslandKind
import com.godly.island.events.ProgressAnchor
import com.godly.island.island.IslandAccent
import com.godly.island.island.IslandEventManager
import com.godly.island.island.IslandRuntime
import com.godly.island.notifications.GodlyNotificationListener

/**
 * Follows the active media session (Spotify, YouTube Music, Samsung Music, ...). Title, artist, album art,
 * playback position and the transport buttons are the real ones from MediaSession.
 * Needs notification access (Android only lets enabled listeners read media sessions).
 */
class MediaWatcher(private val context: Context) {
    private val handler = Handler(Looper.getMainLooper())
    private val msm = context.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
    private val component = ComponentName(context, GodlyNotificationListener::class.java)
    private var controllers: List<MediaController> = emptyList()
    private val callbacks = HashMap<MediaController, MediaController.Callback>()
    private var started = false

    private var lastArtSrc: Bitmap? = null
    private var lastArt: Bitmap? = null
    private var lastAccent: IslandAccent? = null

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
        setControllers(list ?: emptyList())
    }

    fun start() {
        if (started) return
        started = true
        try {
            msm.addOnActiveSessionsChangedListener(sessionsListener, component, handler)
            setControllers(msm.getActiveSessions(component))
        } catch (t: SecurityException) {
            ErrorLog.add("media", "No access to media sessions: " + (t.message ?: ""))
        }
    }

    fun stop() {
        if (!started) return
        started = false
        try {
            msm.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (_: Throwable) {
        }
        for ((c, cb) in callbacks) {
            try {
                c.unregisterCallback(cb)
            } catch (_: Throwable) {
            }
        }
        callbacks.clear()
        controllers = emptyList()
        IslandEventManager.remove(ID)
    }

    private fun setControllers(list: List<MediaController>) {
        for ((c, cb) in callbacks) {
            try {
                c.unregisterCallback(cb)
            } catch (_: Throwable) {
            }
        }
        callbacks.clear()
        controllers = list
        for (c in list) {
            val cb = object : MediaController.Callback() {
                override fun onMetadataChanged(metadata: MediaMetadata?) = refresh()
                override fun onPlaybackStateChanged(state: PlaybackState?) = refresh()
                override fun onSessionDestroyed() = refresh()
            }
            try {
                c.registerCallback(cb, handler)
                callbacks[c] = cb
            } catch (_: Throwable) {
            }
        }
        refresh()
    }

    fun refresh() {
        if (!started || !IslandRuntime.running || !IslandRuntime.settings.fMusic) {
            IslandEventManager.remove(ID)
            return
        }
        val c = controllers.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: controllers.firstOrNull {
                val st = it.playbackState?.state
                st == PlaybackState.STATE_PAUSED || st == PlaybackState.STATE_BUFFERING
            }
        if (c == null) {
            IslandEventManager.remove(ID)
            return
        }
        val md = c.metadata
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE).orEmpty()
        if (title.isBlank()) {
            IslandEventManager.remove(ID)
            return
        }
        val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE).orEmpty()
        val artSrc = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        prepareArt(artSrc)

        val st = c.playbackState
        val playing = st?.state == PlaybackState.STATE_PLAYING
        val dur = md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        val anchor = if (st != null && dur > 0L) {
            ProgressAnchor(st.position, dur, if (st.playbackSpeed > 0f) st.playbackSpeed else 1f, st.lastPositionUpdateTime)
        } else {
            null
        }
        val tc = c.transportControls
        val actions = listOf(
            IslandAction(ActionKind.PREV, safe { tc.skipToPrevious() }),
            if (playing) IslandAction(ActionKind.PAUSE, safe { tc.pause() }) else IslandAction(ActionKind.PLAY, safe { tc.play() }),
            IslandAction(ActionKind.NEXT, safe { tc.skipToNext() }),
        )
        val session = c.sessionActivity
        val open: (() -> Unit)? = if (session == null) null else safe { session.send() }
        IslandEventManager.post(
            IslandEvent(
                id = ID,
                kind = IslandKind.MUSIC,
                title = title,
                subtitle = artist,
                art = lastArt,
                accent = lastAccent,
                playing = playing,
                anchor = anchor,
                ttlMs = if (playing) 0L else 15000L,
                label = appName(c.packageName),
                actions = actions,
                onOpen = open,
            ),
        )
    }

    private fun safe(block: () -> Unit): () -> Unit = {
        try {
            block()
        } catch (_: Throwable) {
        }
    }

    private fun appName(pkg: String): String? = try {
        val pm = context.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (_: Throwable) {
        null
    }

    /** Square-crops + shrinks the album art once per track and derives the Island colours from it. */
    private fun prepareArt(src: Bitmap?) {
        if (src === lastArtSrc) return
        lastArtSrc = src
        if (src == null || src.isRecycled || src.width < 2 || src.height < 2) {
            lastArt = null
            lastAccent = null
            return
        }
        try {
            val m = minOf(src.width, src.height)
            val square = Bitmap.createBitmap(src, (src.width - m) / 2, (src.height - m) / 2, m, m)
            lastArt = Bitmap.createScaledBitmap(square, 96, 96, true)
            val px = Bitmap.createScaledBitmap(square, 1, 1, true).getPixel(0, 0)
            val hsv = FloatArray(3)
            android.graphics.Color.colorToHSV(px, hsv)
            lastAccent = if (hsv[1] < 0.12f) {
                null
            } else {
                val s = hsv[1].coerceIn(0.55f, 0.95f)
                IslandAccent(Color.hsv(hsv[0], s, 0.92f), Color.hsv((hsv[0] + 24f) % 360f, s, 0.58f))
            }
        } catch (_: Throwable) {
            lastArt = null
            lastAccent = null
        }
    }

    private companion object {
        const val ID = "media"
    }
}
