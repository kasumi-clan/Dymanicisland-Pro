package com.godly.island.core

import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.LayoutDirection
import com.godly.island.i18n.L10n

object GodlyColors {
    val Ink = Color(0xFF0B0B0C)
    val Panel = Color(0xFF151517)
    val Paper = Color(0xFFF4F4F2)
    val Muted = Color(0xFF9A9AA0)
    val Ok = Color(0xFF7BE0A4)
    val Bad = Color(0xFFFF6B6B)
    val Warn = Color(0xFFFFC857)
}

@Composable
fun GodlyTheme(content: @Composable () -> Unit) {
    val dir = if (L10n.rtl) LayoutDirection.Rtl else LayoutDirection.Ltr
    CompositionLocalProvider(LocalLayoutDirection provides dir) {
        MaterialTheme(
            colorScheme = darkColorScheme(
                primary = GodlyColors.Paper,
                onPrimary = GodlyColors.Ink,
                background = GodlyColors.Ink,
                onBackground = GodlyColors.Paper,
                surface = GodlyColors.Panel,
                onSurface = GodlyColors.Paper,
            ),
        ) {
            CompositionLocalProvider(LocalTextStyle provides TextStyle(fontFamily = GodlyFont)) {
                content()
            }
        }
    }
}
