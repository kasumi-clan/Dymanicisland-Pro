package com.godly.island.island

import androidx.compose.ui.graphics.Color
import com.godly.island.events.IslandEvent
import com.godly.island.events.IslandKind

/** Two accent colours. Bright mid-tones: readable with white text, never muddy. */
data class IslandAccent(val a: Color, val b: Color)

object IslandPalette {
    private val idle = IslandAccent(Color(0xFF1B1B1F), Color(0xFF000000))

    fun forEvent(ev: IslandEvent?): IslandAccent = ev?.accent ?: accent(ev?.kind)

    /** null = idle pill (no event). */
    fun accent(kind: IslandKind?): IslandAccent = when (kind) {
        null -> idle
        IslandKind.CALL_INCOMING -> IslandAccent(Color(0xFF24C777), Color(0xFF0B8F55))
        IslandKind.CALL_ONGOING -> IslandAccent(Color(0xFF19BDAA), Color(0xFF087F78))
        IslandKind.MUSIC -> IslandAccent(Color(0xFFFF4D8D), Color(0xFF7C3AED))
        IslandKind.MESSAGE -> IslandAccent(Color(0xFF0A7CFF), Color(0xFFA033FF))
        IslandKind.MAIL -> IslandAccent(Color(0xFFEA4335), Color(0xFFB3261E))
        IslandKind.NOTIFICATION -> IslandAccent(Color(0xFF3D8BFF), Color(0xFF5146E5))
        IslandKind.BATTERY_LOW -> IslandAccent(Color(0xFFFF6A4D), Color(0xFFC71F4F))
        IslandKind.BATTERY_FULL -> IslandAccent(Color(0xFF34D27B), Color(0xFF0E9F6E))
        IslandKind.CHARGING -> IslandAccent(Color(0xFF2BD16C), Color(0xFF0E9F8E))
        IslandKind.TIMER -> IslandAccent(Color(0xFFFF9A1F), Color(0xFFE8531D))
        IslandKind.NAVIGATION -> IslandAccent(Color(0xFF2E8BFF), Color(0xFF0FA89A))
        IslandKind.BLUETOOTH -> IslandAccent(Color(0xFF3B82F6), Color(0xFF1D4ED8))
        IslandKind.DOWNLOAD -> IslandAccent(Color(0xFF12B5E5), Color(0xFF2557F0))
    }

    /** Colour of well-known apps (message / social / mail / shop). null = use the kind's colour. */
    fun appAccent(pkg: String): IslandAccent? = when {
        pkg == "com.facebook.orca" || pkg == "com.facebook.mlite" -> IslandAccent(Color(0xFF0A7CFF), Color(0xFFA033FF))
        pkg == "com.zing.zalo" -> IslandAccent(Color(0xFF0068FF), Color(0xFF0043B0))
        pkg.startsWith("com.whatsapp") -> IslandAccent(Color(0xFF25D366), Color(0xFF128C7E))
        pkg.startsWith("org.telegram") || pkg == "org.thunderdog.challegram" -> IslandAccent(Color(0xFF2AABEE), Color(0xFF1B7FBF))
        pkg == "com.discord" -> IslandAccent(Color(0xFF5865F2), Color(0xFF404EED))
        pkg == "com.instagram.android" -> IslandAccent(Color(0xFFFD5949), Color(0xFFD6249F))
        pkg == "com.facebook.katana" -> IslandAccent(Color(0xFF1877F2), Color(0xFF0C5BD0))
        pkg == "com.zhiliaoapp.musically" || pkg == "com.ss.android.ugc.trill" -> IslandAccent(Color(0xFFFF2D55), Color(0xFF21A8B8))
        pkg == "com.google.android.gm" -> IslandAccent(Color(0xFFEA4335), Color(0xFFB3261E))
        pkg.startsWith("com.shopee") -> IslandAccent(Color(0xFFFF6A2B), Color(0xFFEE4D2D))
        pkg == "com.viber.voip" -> IslandAccent(Color(0xFF7360F2), Color(0xFF59267C))
        pkg == "jp.naver.line.android" -> IslandAccent(Color(0xFF06C755), Color(0xFF049A41))
        else -> null
    }
}
