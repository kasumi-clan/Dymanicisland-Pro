package com.godly.island

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.godly.island.core.GodlyButton
import com.godly.island.core.GodlyColors
import com.godly.island.core.GodlyTheme
import com.godly.island.i18n.tr
import com.godly.island.island.IslandLauncher
import com.godly.island.island.IslandPreviewControl
import com.godly.island.island.IslandRuntime
import com.godly.island.settings.IslandSettingsActivity
import com.godly.island.testing.GodlyIslandTestActivity

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        // bring the Island back after the app was closed, if it was on and the permission is still granted
        if (IslandRuntime.settings.enabled && IslandLauncher.hasOverlayPermission(this) && !IslandRuntime.running) {
            IslandLauncher.start(this)
        }
        setContent {
            GodlyTheme {
                HomeScreen(
                    onSettings = { startActivity(Intent(this@MainActivity, IslandSettingsActivity::class.java)) },
                    onTest = { startActivity(Intent(this@MainActivity, GodlyIslandTestActivity::class.java)) },
                )
            }
        }
    }
}

@Composable
private fun HomeScreen(onSettings: () -> Unit, onTest: () -> Unit) {
    val context = LocalContext.current
    val running = IslandRuntime.running
    val postLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    Column(
        Modifier
            .fillMaxSize()
            .background(GodlyColors.Ink)
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically),
    ) {
        Text("Godly Island", color = GodlyColors.Paper, fontSize = 38.sp, fontWeight = FontWeight.ExtraBold)
        Text(tr("tagline"), color = GodlyColors.Muted, fontSize = 14.sp)
        Text(
            if (running) tr("on") else tr("off"),
            color = if (running) GodlyColors.Ok else GodlyColors.Muted,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
        )
        GodlyButton(
            text = if (running) tr("turn_off") else tr("turn_on"),
            onClick = {
                if (running) {
                    IslandPreviewControl.stop()
                    IslandLauncher.stop(context)
                } else {
                    if (Build.VERSION.SDK_INT >= 33 &&
                        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
                        PackageManager.PERMISSION_GRANTED
                    ) {
                        postLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                    IslandLauncher.start(context)
                }
            },
            modifier = Modifier.fillMaxWidth(),
            filled = true,
        )
        GodlyButton(tr("settings"), onSettings, Modifier.fillMaxWidth())
        GodlyButton(tr("test"), onTest, Modifier.fillMaxWidth())
    }
}
