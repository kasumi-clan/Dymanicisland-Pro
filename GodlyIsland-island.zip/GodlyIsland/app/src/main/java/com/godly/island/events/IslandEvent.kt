package com.godly.island.events

import android.graphics.Bitmap
import com.godly.island.island.IslandAccent

/** What the Island is showing. Higher priority wins the main pill when several are active. */
enum class IslandKind(val priority: Int) {
    CALL_INCOMING(100),
    CALL_ONGOING(90),
    BATTERY_LOW(80),
    MESSAGE(70),
    MAIL(69),
    NOTIFICATION(68),
    TIMER(60),
    NAVIGATION(55),
    DOWNLOAD(50),
    CHARGING(45),
    BLUETOOTH(40),
    BATTERY_FULL(35),
    MUSIC(30),
}

enum class ActionKind { ANSWER, DECLINE, PREV, PLAY, PAUSE, NEXT }

/** A button the Island can show (answer / decline a call, music transport). [run] performs the real action. */
class IslandAction(val kind: ActionKind, val run: () -> Unit)

/** A live clock: elapsed since [baseMs] (call duration) or remaining until [baseMs] (timer). */
class ClockSpec(val baseMs: Long, val countDown: Boolean)

/** Where the playback position was at SystemClock.elapsedRealtime() == [atElapsed]. */
class ProgressAnchor(val posMs: Long, val durMs: Long, val speed: Float, val atElapsed: Long)

/**
 * One thing the Island can show.
 * [value] = short text for compact views ("68%"). [ttlMs] = auto-remove after this long (0 = until removed).
 * [simulated] = produced by Test Mode only; never a real notification or call.
 */
data class IslandEvent(
    val id: String,
    val kind: IslandKind,
    val title: String,
    val subtitle: String = "",
    val value: String? = null,
    val progress: Float? = null,
    val ttlMs: Long = 0L,
    val simulated: Boolean = false,
    val label: String? = null,
    val accent: IslandAccent? = null,
    val art: Bitmap? = null,
    val playing: Boolean = true,
    val clock: ClockSpec? = null,
    val anchor: ProgressAnchor? = null,
    val actions: List<IslandAction> = emptyList(),
    val onOpen: (() -> Unit)? = null,
)
