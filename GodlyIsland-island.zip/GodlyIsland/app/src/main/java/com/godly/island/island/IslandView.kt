package com.godly.island.island

import android.os.Build
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CornerSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.godly.island.core.GodlyFont
import com.godly.island.events.ActionKind
import com.godly.island.events.IslandEvent
import com.godly.island.events.IslandKind
import com.godly.island.renderer.IslandMaterial
import kotlin.math.roundToInt
import kotlin.math.sqrt
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private data class ContentKey(val shape: IslandShape, val id: String?)

/** Smoothly blends the body colours when the event (and so the accent) changes. */
private class ColorTrack(initial: IslandAccent) {
    var fa = initial.a
    var fb = initial.b
    var ta = initial.a
    var tb = initial.b
    val t = Animatable(1f)

    fun a(): Color = lerp(fa, ta, t.value)
    fun b(): Color = lerp(fb, tb, t.value)

    suspend fun retarget(n: IslandAccent) {
        fa = a()
        fb = b()
        ta = n.a
        tb = n.b
        t.snapTo(0f)
        t.animateTo(1f, tween(IslandAnimationController.COLOR_MS, easing = IslandAnimationController.colorEasing))
    }
}

/**
 * The Dynamic Island, used by the real overlay and by Test.
 *
 * Smoothness: every animated value is an Animatable read only in layout / draw lambdas (no
 * recomposition per frame); content is laid out once at its final size and revealed by the growing
 * body; the body is one shader draw (plain black when idle, so an idle Island costs nothing).
 */
@Composable
fun IslandView(
    settings: IslandSettings,
    shape: IslandShape,
    events: List<IslandEvent>,
    topPaddingDp: Float,
    modifier: Modifier = Modifier,
    onWindowNeeds: (Float, Float) -> Unit = { _, _ -> },
    onTransitionEnd: () -> Unit = {},
    onTap: () -> Unit = {},
    onLongPress: () -> Unit = {},
    onSwipeUp: () -> Unit = {},
) {
    val context = LocalContext.current
    val d = LocalDensity.current.density
    val haptic = LocalHapticFeedback.current
    val screenW = LocalConfiguration.current.screenWidthDp.toFloat()
    val scope = rememberCoroutineScope()
    val black = settings.style == IslandStyle.BLACK

    val spec = settings.specFor(shape, screenW)
    val window = settings.windowSizeDp(shape, screenW)
    val material = remember { IslandMaterial.create(context) }

    // keep the last events on screen briefly after they vanish so the exit can fade out
    val current = events.toList()
    var held by remember { mutableStateOf(current) }
    LaunchedEffect(current) {
        if (current.isNotEmpty()) {
            held = current
        } else {
            delay(220)
            held = emptyList()
        }
    }
    val shown = if (current.isNotEmpty()) current else held
    val active = current.isNotEmpty()
    val primary = shown.getOrNull(0)
    val secondary = shown.getOrNull(1) ?: (if (spec.dual && primary?.kind == IslandKind.MUSIC) primary else null)

    val tw = spec.w * d
    val th = spec.h * d
    val td = if (spec.dual) 1f else 0f
    val circleDp = settings.miniH

    val wA = remember { Animatable(settings.miniH * d * 0.6f) }
    val hA = remember { Animatable(settings.miniH * d * 0.6f) }
    val dualA = remember { Animatable(0f) }
    val mixA = remember { Animatable(0f) }
    val shake = remember { Animatable(0f) }
    val flash = remember { Animatable(0f) }
    val press = remember { Animatable(1f) }
    val bgTime = remember { mutableFloatStateOf(0f) }

    val trackMain = remember { ColorTrack(IslandPalette.forEvent(primary)) }
    val trackSec = remember { ColorTrack(IslandPalette.forEvent(secondary)) }
    val accentMain = IslandPalette.forEvent(primary)
    val accentSec = IslandPalette.forEvent(secondary)
    LaunchedEffect(accentMain) { trackMain.retarget(accentMain) }
    LaunchedEffect(accentSec) { trackSec.retarget(accentSec) }

    // body geometry: spring with a little overshoot when growing, firm when shrinking
    LaunchedEffect(tw, th, td) {
        onWindowNeeds(window.first, window.second)
        val growing = tw * th >= wA.value * hA.value
        val fs = if (growing) IslandAnimationController.growSpec else IslandAnimationController.shrinkSpec
        IslandAnimationController.begin()
        coroutineScope {
            launch { wA.animateTo(tw, fs) }
            launch { hA.animateTo(th, fs) }
            launch { dualA.animateTo(td, IslandAnimationController.dualSpec) }
        }
        IslandAnimationController.end()
        onTransitionEnd()
    }

    // black at rest -> colour wash while an event is shown
    LaunchedEffect(active) {
        mixA.animateTo(if (active) 1f else 0f, tween(if (active) 420 else 260, easing = FastOutSlowInEasing))
    }

    // flowing background: ~30 fps while expanded, ~20 fps in the compact states, nothing at rest
    val compact = shape == IslandShape.MINI || shape == IslandShape.DUAL
    val animateBg = active && !black && shape != IslandShape.HIDDEN
    LaunchedEffect(animateBg, compact) {
        if (animateBg) {
            val step = if (compact) 50_000_000L else 33_000_000L
            var last = withFrameNanos { it }
            while (true) {
                withFrameNanos { now ->
                    val dt = now - last
                    if (dt >= step) {
                        bgTime.floatValue += dt / 1_000_000_000f
                        last = now
                    }
                }
            }
        }
    }

    // per-function effects when a new event appears: shake, flash, haptic
    LaunchedEffect(primary?.id) {
        val ev = primary ?: return@LaunchedEffect
        val k = ev.kind
        if (IslandFx.flashes(k)) {
            launch {
                delay(120)
                flash.snapTo(0f)
                flash.animateTo(1f, tween(150))
                flash.animateTo(0f, tween(500))
            }
        }
        IslandHaptics.play(context, k, ev.simulated)
        val amp = IslandFx.shakeDp(k) * d
        if (amp > 0f) {
            delay(140)
            val stiff = 900f
            do {
                shake.snapTo(0f)
                shake.animateTo(0f, spring(dampingRatio = 0.2f, stiffness = stiff), initialVelocity = amp * sqrt(stiff))
                if (IslandFx.repeatsShake(k)) delay(1300)
            } while (IslandFx.repeatsShake(k))
        }
    }

    val tapCb by rememberUpdatedState(onTap)
    val longCb by rememberUpdatedState(onLongPress)
    val swipeCb by rememberUpdatedState(onSwipeUp)
    val dragPx = 20f * d

    BoxWithConstraints(
        modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        scope.launch { press.animateTo(0.965f, tween(90)) }
                        tryAwaitRelease()
                        scope.launch { press.animateTo(1f, spring(dampingRatio = 0.5f, stiffness = 520f)) }
                    },
                    onTap = { tapCb() },
                    onLongPress = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        longCb()
                    },
                )
            }
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total < -dragPx) swipeCb() },
                    onVerticalDrag = { _, dy -> total += dy },
                )
            },
    ) {
        val cx = constraints.maxWidth / 2f
        val topPx = topPaddingDp * d
        val gapPx = DUAL_GAP_DP * d
        val circlePx = circleDp * d
        val maxR = 44f * d
        val rimCap = 26f * d
        val showSecond by remember { derivedStateOf { dualA.value > 0.02f } }
        val visible by remember { derivedStateOf { hA.value > 6f } }
        val dualSpec = settings.specFor(IslandShape.DUAL, screenW)

        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = press.value
                    scaleY = press.value
                    translationX = shake.value
                    transformOrigin = TransformOrigin(0.5f, 0f)
                },
        ) {
            Pill(
                x = { cx - wA.value / 2f + (-(gapPx / 2f) - wA.value / 2f) * dualA.value },
                y = { topPx },
                w = { wA.value },
                h = { hA.value },
                fade = { 1f },
                track = trackMain,
                material = material,
                settings = settings,
                maxRadiusPx = maxR,
                rimCapPx = rimCap,
                density = d,
                mix = { mixA.value },
                time = { bgTime.floatValue },
                flash = { flash.value },
                contentW = spec.w,
                contentH = spec.h,
            ) {
                if (visible) {
                    key(ContentKey(shape, primary?.id)) {
                        ContentHost(primary?.kind, 90L) { enter ->
                            PillContent(primary, shape, spec.h, black, enter)
                        }
                    }
                }
            }
            if (showSecond) {
                Pill(
                    x = { cx + gapPx / 2f },
                    y = { topPx },
                    w = { circlePx * dualA.value },
                    h = { hA.value },
                    fade = { dualA.value.coerceIn(0f, 1f) },
                    track = trackSec,
                    material = material,
                    settings = settings,
                    maxRadiusPx = maxR,
                    rimCapPx = rimCap,
                    density = d,
                    mix = { if (secondary != null) mixA.value else 0f },
                    time = { bgTime.floatValue + 3.1f },
                    flash = { flash.value },
                    contentW = circleDp,
                    contentH = dualSpec.h,
                ) {
                    key(ContentKey(IslandShape.DUAL, secondary?.id)) {
                        ContentHost(secondary?.kind, 170L) { enter ->
                            if (secondary != null) CircleContent(secondary, circleDp, black, enter)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Pill(
    x: () -> Float,
    y: () -> Float,
    w: () -> Float,
    h: () -> Float,
    fade: () -> Float,
    track: ColorTrack,
    material: IslandMaterial,
    settings: IslandSettings,
    maxRadiusPx: Float,
    rimCapPx: Float,
    density: Float,
    mix: () -> Float,
    time: () -> Float,
    flash: () -> Float,
    contentW: Float,
    contentH: Float,
    content: @Composable () -> Unit,
) {
    Box(
        modifier = Modifier
            .offset { IntOffset(x().roundToInt(), y().roundToInt()) }
            .layout { measurable, _ ->
                val pw = w().roundToInt().coerceAtLeast(1)
                val ph = h().roundToInt().coerceAtLeast(1)
                val p = measurable.measure(Constraints.fixed(pw, ph))
                layout(pw, ph) { p.place(0, 0) }
            }
            .graphicsLayer {
                val r = minOf(minOf(h(), w()) / 2f, maxRadiusPx)
                shape = RoundedCornerShape(CornerSize(r))
                clip = true
                alpha = fade()
            }
            .drawBehind {
                val hh = size.height
                val r = minOf(minOf(hh, size.width) / 2f, maxRadiusPx)
                drawIslandBody(
                    settings = settings,
                    material = material,
                    a = track.a(),
                    b = track.b(),
                    w = size.width,
                    h = hh,
                    r = r,
                    rimW = minOf(hh / 2f, rimCapPx),
                    dens = density,
                    mix = mix(),
                    time = time(),
                    flash = flash(),
                )
            },
        contentAlignment = Alignment.Center,
    ) {
        // content has its FINAL size; the growing body (clipped) reveals it
        Box(Modifier.requiredSize(contentW.dp, contentH.dp)) { content() }
    }
}

private fun DrawScope.drawIslandBody(
    settings: IslandSettings,
    material: IslandMaterial,
    a: Color,
    b: Color,
    w: Float,
    h: Float,
    r: Float,
    rimW: Float,
    dens: Float,
    mix: Float,
    time: Float,
    flash: Float,
) {
    val sw = maxOf(1f, 1.1f * dens)
    val colourful = settings.style == IslandStyle.COLOR && mix > 0.01f
    if (!colourful) {
        // idle / black style: pure black
        drawRect(color = Color.Black, size = Size(w, h))
        val rim = if (settings.style == IslandStyle.BLACK) lerp(Color.White.copy(alpha = 0.10f), a.copy(alpha = 0.9f), flash) else Color.White.copy(alpha = 0.06f)
        drawRoundRect(
            color = rim,
            topLeft = Offset(sw / 2f, sw / 2f),
            size = Size(w - sw, h - sw),
            cornerRadius = CornerRadius(maxOf(0f, r - sw / 2f)),
            style = Stroke(sw),
        )
        return
    }
    val ok = material.draw(this, w, h, r, a, b, 0.6f + flash * 0.9f, 0.85f, rimW, 1f + flash * 0.8f, mix, time)
    if (ok) return
    // Canvas fallback (Android 12 and older): still coloured
    drawRect(color = Color.Black, size = Size(w, h))
    drawRect(
        brush = Brush.linearGradient(listOf(a, b), start = Offset.Zero, end = Offset(w, h)),
        size = Size(w, h),
        alpha = mix,
    )
    drawRoundRect(
        brush = Brush.linearGradient(
            listOf(Color.White.copy(alpha = 0.65f), Color.White.copy(alpha = 0.12f), Color.White.copy(alpha = 0.40f)),
            start = Offset.Zero,
            end = Offset(w, h),
        ),
        topLeft = Offset(sw / 2f, sw / 2f),
        size = Size(w - sw, h - sw),
        cornerRadius = CornerRadius(maxOf(0f, r - sw / 2f)),
        style = Stroke(sw),
        alpha = mix,
    )
}

/**
 * New content appears after a short delay with a spring pop, a soft fade and — per function — a motion
 * blur along X, Y or both that clears as it settles (Android 12+; older versions skip the blur).
 */
@Composable
private fun ContentHost(kind: IslandKind?, delayMs: Long, content: @Composable (enter: () -> Float) -> Unit) {
    val d = LocalDensity.current.density
    val enter = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(delayMs)
        enter.animateTo(1f, spring(dampingRatio = 0.6f, stiffness = 340f))
    }
    val axis = if (kind == null) IslandFx.Axis.NONE else IslandFx.blurAxis(kind)
    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer {
                val e = enter.value.coerceIn(0f, 1f)
                alpha = ((e - 0.05f) / 0.55f).coerceIn(0f, 1f)
                val sc = 0.94f + 0.06f * enter.value
                scaleX = sc
                scaleY = sc
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && e < 0.98f) {
                    val r = (1f - e) * 14f * d
                    if (r > 0.5f) {
                        val rx = if (axis == IslandFx.Axis.X || axis == IslandFx.Axis.BOTH) r else 0.01f
                        val ry = if (axis == IslandFx.Axis.Y || axis == IslandFx.Axis.BOTH) r else 0.01f
                        renderEffect = BlurEffect(rx, ry, TileMode.Decal)
                    }
                }
            },
    ) { content { enter.value } }
}

// ---------------------------------------------------------------------------------------------
// Content layouts. Every size derives from the body height; every horizontal inset keeps the icon
// clear of the rounded end cap (inset = vertical margin + 10% of height), so nothing sits "sunk".
// ---------------------------------------------------------------------------------------------

@Composable
private fun PillContent(ev: IslandEvent?, shape: IslandShape, h: Float, black: Boolean, enter: () -> Float) {
    if (ev == null) return
    when (shape) {
        IslandShape.MINI, IslandShape.DUAL -> CompactContent(ev, h, black, enter)
        IslandShape.EXPANDED -> ExpandedContent(ev, h, black, enter)
        IslandShape.FULL -> FullContent(ev, h, black, enter)
        IslandShape.HIDDEN -> Unit
    }
}

private fun textStyle(black: Boolean, sizeSp: Float, weight: FontWeight, alpha: Float = 1f): TextStyle =
    TextStyle(
        fontFamily = GodlyFont,
        color = Color.White.copy(alpha = alpha),
        fontSize = sizeSp.sp,
        fontWeight = weight,
        shadow = if (!black) Shadow(Color(0x66000000), Offset(0f, 1.5f), 5f) else null,
    )

@Composable
private fun PopTile(ev: IslandEvent, sizeDp: Float, black: Boolean, enter: () -> Float, iconFraction: Float = 0.62f) {
    Bead(
        IslandPalette.forEvent(ev),
        black,
        sizeDp,
        Modifier.graphicsLayer {
            val s = (0.35f + 0.65f * enter()).coerceAtLeast(0f)
            scaleX = s
            scaleY = s
        },
    ) { IslandIcon(ev.kind, (sizeDp * iconFraction).dp) }
}

@Composable
private fun SlideIn(enter: () -> Float, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val d = LocalDensity.current.density
    Box(
        modifier.graphicsLayer {
            translationX = (1f - enter().coerceIn(0f, 1f)) * -14f * d
        },
    ) { content() }
}

@Composable
private fun Progress(p: Float, heightDp: Float, black: Boolean, ev: IslandEvent, modifier: Modifier = Modifier) {
    val acc = IslandPalette.forEvent(ev)
    val track = if (black) Color.White.copy(alpha = 0.16f) else Color.White.copy(alpha = 0.28f)
    val fill: Brush = if (black) Brush.horizontalGradient(listOf(acc.a, acc.b)) else SolidColor(Color.White)
    GlideBar(p, heightDp, track, fill, modifier)
}

@Composable
private fun CompactContent(ev: IslandEvent, h: Float, black: Boolean, enter: () -> Float) {
    val tile = h * 0.60f
    val inset = 0.5f * (h - tile) + 0.10f * h
    Row(
        Modifier
            .fillMaxSize()
            .padding(horizontal = inset.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy((h * 0.18f).dp),
    ) {
        if (ev.kind == IslandKind.MUSIC) {
            EqBars(Color.White, ev.playing, Modifier.size((tile * 0.8f).dp, (tile * 0.7f).dp))
        } else {
            PopTile(ev, tile, black, enter, 0.70f)
        }
        SlideIn(enter, Modifier.weight(1f)) {
            MarqueeText(
                text = if (ev.kind == IslandKind.MUSIC) ev.title else (liveValue(ev) ?: ev.title),
                style = textStyle(black, h * 0.34f, FontWeight.SemiBold),
            )
        }
    }
}

@Composable
private fun CircleContent(ev: IslandEvent, dDp: Float, black: Boolean, enter: () -> Float) {
    val acc = IslandPalette.forEvent(ev)
    val p = liveProgress(ev)
    Box(
        Modifier
            .fillMaxSize()
            .drawBehind {
                if (p != null) drawRing(p, if (black) acc.a else Color.White, 2.2.dp.toPx())
            },
        contentAlignment = Alignment.Center,
    ) {
        if (ev.kind == IslandKind.MUSIC) {
            Box(
                Modifier.graphicsLayer {
                    val s = (0.35f + 0.65f * enter()).coerceAtLeast(0f)
                    scaleX = s
                    scaleY = s
                },
            ) { Disc(ev.art, acc, ev.playing, dDp * 0.74f) }
        } else {
            PopTile(ev, dDp * 0.74f, black, enter, 0.62f)
        }
    }
}

@Composable
private fun ExpandedContent(ev: IslandEvent, h: Float, black: Boolean, enter: () -> Float) {
    val tile = h * 0.56f
    val inset = 0.5f * (h - tile) + 0.10f * h
    val acc = IslandPalette.forEvent(ev)
    Row(
        Modifier
            .fillMaxSize()
            .padding(horizontal = inset.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy((h * 0.17f).dp),
    ) {
        if (ev.kind == IslandKind.MUSIC) {
            Box(
                Modifier.graphicsLayer {
                    val s = (0.35f + 0.65f * enter()).coerceAtLeast(0f)
                    scaleX = s
                    scaleY = s
                },
            ) { Disc(ev.art, acc, ev.playing, tile) }
        } else {
            PopTile(ev, tile, black, enter)
        }
        SlideIn(enter, Modifier.weight(1f)) {
            Column(verticalArrangement = Arrangement.Center) {
                MarqueeText(ev.title, textStyle(black, h * 0.21f, FontWeight.Bold))
                if (ev.subtitle.isNotEmpty()) {
                    MarqueeText(ev.subtitle, textStyle(black, h * 0.165f, FontWeight.Normal, 0.88f))
                }
                val p = liveProgress(ev)
                if (p != null) Progress(p, h * 0.055f, black, ev, Modifier.padding(top = (h * 0.06f).dp))
            }
        }
        val decline = ev.actions.firstOrNull { it.kind == ActionKind.DECLINE }
        val answer = ev.actions.firstOrNull { it.kind == ActionKind.ANSWER }
        if (ev.kind == IslandKind.CALL_INCOMING && (decline != null || answer != null)) {
            Row(horizontalArrangement = Arrangement.spacedBy((h * 0.12f).dp)) {
                if (decline != null) ActionButton(ActionKind.DECLINE, h * 0.5f, decline.run)
                if (answer != null) ActionButton(ActionKind.ANSWER, h * 0.5f, answer.run)
            }
        } else if (ev.kind == IslandKind.MUSIC) {
            EqBars(Color.White, ev.playing, Modifier.size((h * 0.26f).dp, (h * 0.3f).dp))
        } else {
            val v = liveValue(ev)
            if (v != null) Text(text = v, style = textStyle(black, h * 0.21f, FontWeight.Bold), maxLines = 1)
        }
    }
}

@Composable
private fun FullContent(ev: IslandEvent, h: Float, black: Boolean, enter: () -> Float) {
    val tile = (h * 0.29f).coerceAtMost(56f)
    val pad = (h * 0.11f).coerceIn(14f, 22f)
    val acc = IslandPalette.forEvent(ev)
    Column(
        Modifier
            .fillMaxSize()
            .padding(pad.dp),
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (ev.kind == IslandKind.MUSIC) {
                Disc(ev.art, acc, ev.playing, tile)
            } else {
                PopTile(ev, tile, black, enter)
            }
            SlideIn(enter, Modifier.weight(1f)) {
                Column {
                    MarqueeText(ev.title, textStyle(black, 19f, FontWeight.ExtraBold))
                    if (ev.subtitle.isNotEmpty()) MarqueeText(ev.subtitle, textStyle(black, 13f, FontWeight.Normal, 0.88f))
                }
            }
            val v = liveValue(ev)
            if (v != null && ev.kind != IslandKind.MUSIC) {
                Text(text = v, style = textStyle(black, 19f, FontWeight.Bold), maxLines = 1)
            }
        }
        val p = liveProgress(ev)
        if (ev.kind == IslandKind.CALL_INCOMING && ev.actions.isNotEmpty()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                for (a in ev.actions) ActionButton(a.kind, 46f, a.run)
            }
        } else if (ev.kind == IslandKind.MUSIC) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (p != null) Progress(p, 5f, black, ev)
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    for (a in ev.actions) ActionButton(a.kind, if (a.kind == ActionKind.PLAY || a.kind == ActionKind.PAUSE) 44f else 36f, a.run)
                }
            }
        } else if (p != null) {
            Progress(p, 6f, black, ev)
        }
        val label = ev.label
        if (!label.isNullOrEmpty()) {
            Text(text = label, style = textStyle(black, 11f, FontWeight.Medium, 0.7f), maxLines = 1)
        } else {
            Box(Modifier.size(1.dp))
        }
    }
}
