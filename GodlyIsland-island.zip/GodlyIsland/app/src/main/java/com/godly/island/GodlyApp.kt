package com.godly.island

import android.app.Application
import com.godly.island.i18n.L10n
import com.godly.island.island.IslandRuntime

class GodlyApp : Application() {
    override fun onCreate() {
        super.onCreate()
        L10n.init(this)
        IslandRuntime.load(this)
    }
}
