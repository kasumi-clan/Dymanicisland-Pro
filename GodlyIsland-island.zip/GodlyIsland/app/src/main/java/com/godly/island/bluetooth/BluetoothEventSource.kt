package com.godly.island.bluetooth

import android.bluetooth.BluetoothClass
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import com.godly.island.events.IslandEvent
import com.godly.island.events.IslandKind
import com.godly.island.i18n.L10n
import com.godly.island.island.IslandEventManager
import com.godly.island.island.IslandRuntime

/** Shows when headphones / speakers connect. The device name needs the Bluetooth permission. */
class BluetoothEventSource(private val context: Context) {
    private var started = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, intent: Intent?) {
            if (intent == null || !IslandRuntime.settings.fBluetooth) return
            val device = IntentCompat.getParcelableExtra(intent, BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
            when (intent.action) {
                BluetoothDevice.ACTION_ACL_CONNECTED -> onConnected(device)
                BluetoothDevice.ACTION_ACL_DISCONNECTED -> IslandEventManager.remove(ID)
            }
        }
    }

    fun start() {
        if (started) return
        started = true
        val f = IntentFilter()
        f.addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
        f.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
        ContextCompat.registerReceiver(context, receiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    fun stop() {
        if (!started) return
        started = false
        try {
            context.unregisterReceiver(receiver)
        } catch (_: Throwable) {
        }
    }

    private fun onConnected(device: BluetoothDevice?) {
        var name: String? = null
        var major: Int? = null
        try {
            name = device?.name
            major = device?.bluetoothClass?.majorDeviceClass
        } catch (_: SecurityException) {
        }
        if (major != null && major != BluetoothClass.Device.Major.AUDIO_VIDEO) return
        IslandEventManager.post(
            IslandEvent(
                id = ID,
                kind = IslandKind.BLUETOOTH,
                title = if (name.isNullOrBlank()) L10n.t("bt_device") else name,
                subtitle = L10n.t("connected"),
                ttlMs = 4500L,
            ),
        )
    }

    private companion object {
        const val ID = "bluetooth"
    }
}
