package com.godly.island.battery

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.core.content.ContextCompat
import com.godly.island.events.IslandEvent
import com.godly.island.events.IslandKind
import com.godly.island.i18n.L10n
import com.godly.island.island.IslandEventManager
import com.godly.island.island.IslandRuntime

/**
 * REAL battery events from the system (no permission needed): plug-in, unplug, falling to 20% / 10%,
 * and 100% while plugged. It reports what Android says; it does not guess "fast charging".
 */
class BatteryEventSource(private val context: Context) {
    private var lastPlugged = -1
    private var lastLevel = -1
    private var started = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, intent: Intent?) {
            if (intent != null) handle(intent, false)
        }
    }

    fun start() {
        if (started) return
        started = true
        val sticky = ContextCompat.registerReceiver(
            context,
            receiver,
            IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED,
        )
        if (sticky != null) handle(sticky, true) // remember the starting state, show nothing
    }

    fun stop() {
        if (!started) return
        started = false
        try {
            context.unregisterReceiver(receiver)
        } catch (_: Throwable) {
        }
    }

    private fun handle(intent: Intent, initial: Boolean) {
        val rawLevel = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
        if (rawLevel < 0 || scale <= 0) return
        val level = rawLevel * 100 / scale
        val on = IslandRuntime.settings.fBattery

        if (!initial && on) {
            if (plugged != 0 && lastPlugged == 0) {
                val how = when (plugged) {
                    BatteryManager.BATTERY_PLUGGED_WIRELESS -> L10n.t("plug_wireless")
                    BatteryManager.BATTERY_PLUGGED_USB -> L10n.t("plug_usb")
                    else -> L10n.t("plug_cable")
                }
                IslandEventManager.post(
                    IslandEvent(
                        id = ID_CHARGE,
                        kind = IslandKind.CHARGING,
                        title = L10n.t("charging"),
                        subtitle = how,
                        value = "$level%",
                        progress = level / 100f,
                        ttlMs = 5000L,
                    ),
                )
            } else if (plugged == 0 && lastPlugged > 0) {
                IslandEventManager.remove(ID_CHARGE)
            }
            if (plugged == 0 && level <= 10 && lastLevel > 10) {
                IslandEventManager.post(
                    IslandEvent(
                        id = ID_LOW,
                        kind = IslandKind.BATTERY_LOW,
                        title = L10n.t("battery_critical"),
                        subtitle = L10n.t("plug_in"),
                        value = "$level%",
                        progress = level / 100f,
                        ttlMs = 8000L,
                    ),
                )
            } else if (plugged == 0 && level <= 20 && lastLevel > 20) {
                IslandEventManager.post(
                    IslandEvent(
                        id = ID_LOW,
                        kind = IslandKind.BATTERY_LOW,
                        title = L10n.t("battery_low"),
                        subtitle = L10n.t("plug_in"),
                        value = "$level%",
                        progress = level / 100f,
                        ttlMs = 6000L,
                    ),
                )
            }
            if (plugged != 0 && level >= 100 && lastLevel in 0..99) {
                IslandEventManager.post(
                    IslandEvent(
                        id = ID_FULL,
                        kind = IslandKind.BATTERY_FULL,
                        title = L10n.t("battery_full"),
                        subtitle = L10n.t("can_unplug"),
                        value = "100%",
                        progress = 1f,
                        ttlMs = 5000L,
                    ),
                )
            }
        }
        lastPlugged = plugged
        lastLevel = level
    }

    private companion object {
        const val ID_CHARGE = "battery-charge"
        const val ID_LOW = "battery-low"
        const val ID_FULL = "battery-full"
    }
}
