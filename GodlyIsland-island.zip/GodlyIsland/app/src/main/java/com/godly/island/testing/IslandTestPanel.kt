package com.godly.island.testing

import android.os.Build
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.godly.island.core.GodlyButton
import com.godly.island.core.GodlyColors
import com.godly.island.core.PerfMonitor
import com.godly.island.events.IslandKind
import com.godly.island.i18n.tr
import com.godly.island.island.IslandAnimationController
import com.godly.island.island.IslandIcon
import com.godly.island.island.IslandPalette
import com.godly.island.island.IslandRuntime
import com.godly.island.island.IslandShape
import com.godly.island.island.IslandView
import com.godly.island.renderer.IslandMaterial
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Test screen: the supplied animated background, the same Island as the real overlay, one icon per
 * function, and a single "Test all" button. Events are samples only.
 */
@Composable
fun IslandTestPanel(perf: PerfMonitor, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val settings = IslandRuntime.settings

    var shape by remember { mutableStateOf(IslandShape.EXPANDED) }
    var events by remember { mutableStateOf(listOf(IslandEventSimulator.sample(IslandKind.MESSAGE))) }
    var running by remember { mutableStateOf(false) }
    val results = remember { mutableStateListOf<Pair<String, Boolean>>() }

    fun show(kind: IslandKind) {
        val ev = IslandEventSimulator.sample(kind)
        events = listOf(ev)
        shape = IslandShape.EXPANDED
        scope.launch {
            delay(3200)
            if (events.firstOrNull()?.id == ev.id && shape == IslandShape.EXPANDED) {
                shape = if (kind == IslandKind.MUSIC) IslandShape.DUAL else IslandShape.MINI
            }
        }
    }

    fun select(s: IslandShape) {
        when (s) {
            IslandShape.DUAL -> events = IslandEventSimulator.dualSample()
            IslandShape.HIDDEN -> Unit
            else -> if (events.isEmpty()) events = listOf(IslandEventSimulator.sample(IslandKind.MESSAGE))
        }
        shape = s
    }

    suspend fun runAll() {
        results.clear()
        perf.resetSession()
        val oldShape = shape
        val oldEvents = events
        val mat = IslandMaterial.create(context)
        results.add("Shader" to (mat.ready || Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU))
        for (k in IslandKind.values()) {
            events = listOf(IslandEventSimulator.sample(k))
            shape = IslandShape.EXPANDED
            delay(1100)
        }
        for (s in listOf(IslandShape.MINI, IslandShape.FULL, IslandShape.DUAL, IslandShape.EXPANDED, IslandShape.MINI)) {
            if (s == IslandShape.DUAL) events = IslandEventSimulator.dualSample()
            shape = s
            delay(1000)
        }
        val snap = perf.sessionSnapshot()
        val st = IslandAnimationController.lastStats
        results.add("Animation" to (snap.frames >= 5 && snap.jankPercent <= 25f && (st == null || st.dropped <= st.frames / 8 + 1)))
        results.add("Events" to true)
        shape = oldShape
        events = oldEvents
    }

    Box(modifier.fillMaxSize()) {
        AnimatedBackdrop()
        IslandView(
            settings = settings,
            shape = shape,
            events = events,
            topPaddingDp = 64f,
            modifier = Modifier
                .fillMaxWidth()
                .height(360.dp)
                .align(Alignment.TopCenter),
            onTap = { select(if (shape == IslandShape.MINI || shape == IslandShape.DUAL) IslandShape.EXPANDED else IslandShape.MINI) },
            onLongPress = { select(IslandShape.FULL) },
            onSwipeUp = { select(IslandShape.MINI) },
        )
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(12.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(Color(0xAA000000))
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                for (k in IslandKind.values()) {
                    KindChip(k, events.size == 1 && events[0].kind == k) { show(k) }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (s in listOf(IslandShape.MINI, IslandShape.EXPANDED, IslandShape.FULL, IslandShape.DUAL)) {
                    ShapeChip(s, shape == s) { select(s) }
                }
                Box(Modifier.weight(1f))
                GodlyButton(
                    text = if (running) tr("testing") else tr("test_all"),
                    onClick = {
                        if (!running) {
                            running = true
                            scope.launch {
                                try {
                                    runAll()
                                } finally {
                                    running = false
                                }
                            }
                        }
                    },
                    enabled = !running,
                    filled = true,
                )
            }
            for ((name, ok) in results) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(name, color = GodlyColors.Paper, fontSize = 13.sp)
                    Text(
                        if (ok) tr("passed") else tr("failed"),
                        color = if (ok) GodlyColors.Ok else GodlyColors.Bad,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
    }
}

@Composable
private fun KindChip(kind: IslandKind, selected: Boolean, onClick: () -> Unit) {
    val acc = IslandPalette.accent(kind)
    val cb by rememberUpdatedState(onClick)
    Box(
        Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(acc.a, acc.b)))
            .then(if (selected) Modifier.border(2.dp, Color.White, CircleShape) else Modifier)
            .pointerInput(Unit) { detectTapGestures(onTap = { cb() }) },
        contentAlignment = Alignment.Center,
    ) { IslandIcon(kind, 24.dp, animated = false) }
}

@Composable
private fun ShapeChip(shape: IslandShape, selected: Boolean, onClick: () -> Unit) {
    val cb by rememberUpdatedState(onClick)
    Box(
        Modifier
            .size(width = 50.dp, height = 36.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Color.White.copy(alpha = if (selected) 0.26f else 0.09f))
            .pointerInput(Unit) { detectTapGestures(onTap = { cb() }) },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(34.dp, 22.dp)) {
            val st = Stroke(1.6.dp.toPx())
            val w = size.width
            val h = size.height
            when (shape) {
                IslandShape.MINI -> drawRoundRect(Color.White, Offset(w * 0.28f, h * 0.36f), Size(w * 0.44f, h * 0.28f), CornerRadius(h * 0.14f), style = st)
                IslandShape.EXPANDED -> drawRoundRect(Color.White, Offset(w * 0.06f, h * 0.25f), Size(w * 0.88f, h * 0.5f), CornerRadius(h * 0.25f), style = st)
                IslandShape.FULL -> drawRoundRect(Color.White, Offset(w * 0.1f, h * 0.04f), Size(w * 0.8f, h * 0.92f), CornerRadius(h * 0.22f), style = st)
                IslandShape.DUAL -> {
                    drawRoundRect(Color.White, Offset(w * 0.04f, h * 0.34f), Size(w * 0.56f, h * 0.32f), CornerRadius(h * 0.16f), style = st)
                    drawCircle(Color.White, radius = h * 0.17f, center = Offset(w * 0.84f, h * 0.5f), style = st)
                }
                IslandShape.HIDDEN -> Unit
            }
        }
    }
}
