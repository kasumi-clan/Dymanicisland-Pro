package com.godly.island.settings

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.godly.island.core.GodlyButton
import com.godly.island.core.GodlyCard
import com.godly.island.core.GodlyChip
import com.godly.island.core.GodlyColors
import com.godly.island.core.GodlyTheme
import com.godly.island.core.SectionTitle
import com.godly.island.i18n.L10n
import com.godly.island.i18n.tr
import com.godly.island.island.IslandLauncher
import com.godly.island.island.IslandPreviewControl
import com.godly.island.island.IslandRuntime
import com.godly.island.island.IslandSettings
import com.godly.island.island.IslandStyle
import kotlin.math.roundToInt

class IslandSettingsActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        IslandRuntime.load(this)
        setContent { GodlyTheme { SettingsScreen(tick) } }
    }

    override fun onResume() {
        super.onResume()
        tick++
    }

    override fun onPause() {
        IslandPreviewControl.stop()
        super.onPause()
    }
}

private fun hasBluetoothPermission(context: Context): Boolean =
    Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
        ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

@Composable
private fun SettingsScreen(tick: Int) {
    val context = LocalContext.current
    val s = IslandRuntime.settings
    val running = IslandRuntime.running
    val overlayOk = remember(tick) { IslandLauncher.hasOverlayPermission(context) }
    val notifOk = remember(tick) { IslandLauncher.hasNotificationAccess(context) }
    var btOk by remember(tick) { mutableStateOf(hasBluetoothPermission(context)) }
    var picking by remember { mutableStateOf(false) }
    val postLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val btLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { btOk = it }

    fun change(save: Boolean, f: (IslandSettings) -> IslandSettings) = IslandRuntime.update(context, save, f)
    fun done() = IslandRuntime.persist(context)
    fun adjust(f: (IslandSettings) -> IslandSettings) {
        change(false, f)
        if (running) IslandPreviewControl.showIdle()
    }

    if (picking) {
        LanguagePicker(
            onPick = {
                L10n.set(context, it)
                picking = false
            },
            onBack = { picking = false },
        )
        return
    }

    val lang = L10n.languages.firstOrNull { it.code == L10n.code }

    Box(Modifier.fillMaxSize().background(GodlyColors.Ink)) {
        Column(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text(tr("settings"), color = GodlyColors.Paper, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)

            GodlyCard {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        SectionTitle("Dynamic Island")
                        Text(
                            if (running) tr("on") else tr("off"),
                            color = if (running) GodlyColors.Ok else GodlyColors.Muted,
                            fontSize = 12.sp,
                        )
                    }
                    Switch(
                        checked = running,
                        onCheckedChange = { on ->
                            if (on) {
                                if (Build.VERSION.SDK_INT >= 33 &&
                                    ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
                                    PackageManager.PERMISSION_GRANTED
                                ) {
                                    postLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                }
                                IslandLauncher.start(context)
                            } else {
                                IslandPreviewControl.stop()
                                IslandLauncher.stop(context)
                            }
                        },
                        colors = SwitchDefaults.colors(checkedThumbColor = GodlyColors.Ink, checkedTrackColor = GodlyColors.Paper),
                    )
                }
            }

            GodlyCard {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { picking = true },
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text(lang?.flag ?: "", fontSize = 26.sp)
                    Column(Modifier.weight(1f)) {
                        SectionTitle(tr("language"))
                        Text(lang?.native ?: "English", color = GodlyColors.Muted, fontSize = 13.sp)
                    }
                }
            }

            GodlyCard {
                SectionTitle(tr("style"))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GodlyChip(tr("style_color"), s.style == IslandStyle.COLOR, { change(true) { it.copy(style = IslandStyle.COLOR) } })
                    GodlyChip(tr("style_black"), s.style == IslandStyle.BLACK, { change(true) { it.copy(style = IslandStyle.BLACK) } })
                }
                SwitchRow(tr("always_show"), s.showIdle) { v -> change(true) { it.copy(showIdle = v) } }
                SwitchRow(tr("vibration"), s.haptics) { v -> change(true) { it.copy(haptics = v) } }
            }

            GodlyCard {
                SectionTitle(tr("size"))
                ValueSlider(tr("width"), s.miniW, 80f, 240f, { v -> adjust { it.copy(miniW = v) } }, { done() })
                ValueSlider(tr("height"), s.miniH, 26f, 60f, { v -> adjust { it.copy(miniH = v) } }, { done() })
            }

            GodlyCard {
                SectionTitle(tr("position"))
                ValueSlider(tr("horizontal"), s.offsetX, -240f, 240f, { v -> adjust { it.copy(offsetX = v) } }, { done() })
                ValueSlider(tr("vertical"), s.offsetY, -120f, 120f, { v -> adjust { it.copy(offsetY = v) } }, { done() })
                GodlyButton(tr("reset"), { change(true) { it.copy(offsetX = 0f, offsetY = 0f) } }, Modifier.fillMaxWidth())
            }

            GodlyCard {
                SectionTitle(tr("events"))
                SwitchRow(tr("ev_notifications"), s.fNotif) { v -> change(true) { it.copy(fNotif = v) } }
                SwitchRow(tr("ev_music"), s.fMusic) { v -> change(true) { it.copy(fMusic = v) } }
                SwitchRow(tr("ev_calls"), s.fCall) { v -> change(true) { it.copy(fCall = v) } }
                SwitchRow(tr("ev_navigation"), s.fNav) { v -> change(true) { it.copy(fNav = v) } }
                SwitchRow(tr("ev_battery"), s.fBattery) { v -> change(true) { it.copy(fBattery = v) } }
                SwitchRow(tr("ev_bluetooth"), s.fBluetooth) { v -> change(true) { it.copy(fBluetooth = v) } }
                SwitchRow(tr("ev_downloads"), s.fDownload) { v -> change(true) { it.copy(fDownload = v) } }
                SwitchRow(tr("ev_timers"), s.fTimer) { v -> change(true) { it.copy(fTimer = v) } }
                SwitchRow(tr("hide_content"), s.hideContent) { v -> change(true) { it.copy(hideContent = v) } }
            }

            GodlyCard {
                SectionTitle(tr("permissions"))
                PermRow(tr("perm_overlay"), overlayOk) { IslandLauncher.openOverlaySettings(context) }
                PermRow(tr("perm_notif"), notifOk) { IslandLauncher.openNotificationAccess(context) }
                PermRow(tr("perm_bluetooth"), btOk) { btLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT) }
            }
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = GodlyColors.Paper, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedThumbColor = GodlyColors.Ink, checkedTrackColor = GodlyColors.Paper),
        )
    }
}

@Composable
private fun PermRow(label: String, ok: Boolean, onGrant: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(label, color = GodlyColors.Paper, fontSize = 14.sp, modifier = Modifier.weight(1f))
        if (ok) {
            Text(tr("granted"), color = GodlyColors.Ok, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        } else {
            GodlyButton(tr("grant"), onGrant)
        }
    }
}

@Composable
private fun ValueSlider(
    label: String,
    value: Float,
    min: Float,
    max: Float,
    onChange: (Float) -> Unit,
    onDone: () -> Unit,
) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = GodlyColors.Paper, fontSize = 14.sp)
            Text(value.roundToInt().toString(), color = GodlyColors.Muted, fontSize = 13.sp)
        }
        Slider(
            value = value.coerceIn(min, max),
            onValueChange = onChange,
            onValueChangeFinished = onDone,
            valueRange = min..max,
            colors = SliderDefaults.colors(
                thumbColor = GodlyColors.Paper,
                activeTrackColor = GodlyColors.Paper,
                inactiveTrackColor = Color.White.copy(alpha = 0.2f),
            ),
        )
    }
}
