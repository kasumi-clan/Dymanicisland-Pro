package com.godly.island.island

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

enum class IslandStyle {
    /** Black at rest, colourful animated body while an event is shown. */
    COLOR,

    /** Pure black body like the iPhone 14 Pro Max; colour only in the icon, bar and text. */
    BLACK,
}

/** Everything the user can tune. Sizes are dp. */
data class IslandSettings(
    val enabled: Boolean = false,
    val style: IslandStyle = IslandStyle.COLOR,
    val showIdle: Boolean = true,
    val miniW: Float = 126f,
    val miniH: Float = 37f,
    val offsetX: Float = 0f,
    val offsetY: Float = 0f,
    val haptics: Boolean = true,
    val hideContent: Boolean = false,
    val fNotif: Boolean = true,
    val fMusic: Boolean = true,
    val fCall: Boolean = true,
    val fNav: Boolean = true,
    val fBattery: Boolean = true,
    val fBluetooth: Boolean = true,
    val fDownload: Boolean = true,
    val fTimer: Boolean = true,
)

class IslandSettingsStore(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("godly_island_island_v3", Context.MODE_PRIVATE)

    fun load(): IslandSettings {
        val d = IslandSettings()
        return IslandSettings(
            enabled = prefs.getBoolean("enabled", d.enabled),
            style = runCatching { IslandStyle.valueOf(prefs.getString("style", null) ?: d.style.name) }
                .getOrDefault(d.style),
            showIdle = prefs.getBoolean("showIdle", d.showIdle),
            miniW = prefs.getFloat("miniW", d.miniW),
            miniH = prefs.getFloat("miniH", d.miniH),
            offsetX = prefs.getFloat("offsetX", d.offsetX),
            offsetY = prefs.getFloat("offsetY", d.offsetY),
            haptics = prefs.getBoolean("haptics", d.haptics),
            hideContent = prefs.getBoolean("hideContent", d.hideContent),
            fNotif = prefs.getBoolean("fNotif", d.fNotif),
            fMusic = prefs.getBoolean("fMusic", d.fMusic),
            fCall = prefs.getBoolean("fCall", d.fCall),
            fNav = prefs.getBoolean("fNav", d.fNav),
            fBattery = prefs.getBoolean("fBattery", d.fBattery),
            fBluetooth = prefs.getBoolean("fBluetooth", d.fBluetooth),
            fDownload = prefs.getBoolean("fDownload", d.fDownload),
            fTimer = prefs.getBoolean("fTimer", d.fTimer),
        )
    }

    fun save(s: IslandSettings) {
        prefs.edit()
            .putBoolean("enabled", s.enabled)
            .putString("style", s.style.name)
            .putBoolean("showIdle", s.showIdle)
            .putFloat("miniW", s.miniW)
            .putFloat("miniH", s.miniH)
            .putFloat("offsetX", s.offsetX)
            .putFloat("offsetY", s.offsetY)
            .putBoolean("haptics", s.haptics)
            .putBoolean("hideContent", s.hideContent)
            .putBoolean("fNotif", s.fNotif)
            .putBoolean("fMusic", s.fMusic)
            .putBoolean("fCall", s.fCall)
            .putBoolean("fNav", s.fNav)
            .putBoolean("fBattery", s.fBattery)
            .putBoolean("fBluetooth", s.fBluetooth)
            .putBoolean("fDownload", s.fDownload)
            .putBoolean("fTimer", s.fTimer)
            .apply()
    }
}

/** Process-wide live state shared by the overlay Service, Settings and Test. Main thread only. */
object IslandRuntime {
    var settings by mutableStateOf(IslandSettings())
    var running by mutableStateOf(false)

    fun load(context: Context) {
        settings = IslandSettingsStore(context).load()
    }

    fun persist(context: Context) {
        IslandSettingsStore(context).save(settings)
    }

    /** Applies [block] immediately (the real Island reacts live); writes to disk when [save] is true. */
    fun update(context: Context, save: Boolean = true, block: (IslandSettings) -> IslandSettings) {
        settings = block(settings)
        if (save) persist(context)
    }
}
