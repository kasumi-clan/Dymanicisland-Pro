package com.godly.island.notifications

import android.app.Notification
import android.content.Context
import android.content.pm.ApplicationInfo
import android.os.Bundle
import android.service.notification.StatusBarNotification
import androidx.core.os.BundleCompat
import com.godly.island.events.ActionKind
import com.godly.island.events.ClockSpec
import com.godly.island.events.IslandAction
import com.godly.island.events.IslandEvent
import com.godly.island.events.IslandKind
import com.godly.island.i18n.L10n
import com.godly.island.island.IslandPalette
import com.godly.island.island.IslandRuntime

/**
 * Turns a real system notification into an Island event. Nothing is invented: every title, text,
 * progress and clock comes from the notification itself.
 */
object NotificationMapper {
    private val chatPkgs = setOf(
        "com.facebook.orca", "com.facebook.mlite", "com.facebook.katana", "com.zing.zalo", "com.whatsapp",
        "com.whatsapp.w4b", "org.telegram.messenger", "org.telegram.messenger.web", "org.thunderdog.challegram",
        "com.discord", "com.instagram.android", "com.viber.voip", "jp.naver.line.android", "com.tencent.mm",
        "com.skype.raider", "com.snapchat.android", "com.google.android.apps.messaging",
        "com.samsung.android.messaging", "com.android.mms", "com.zhiliaoapp.musically", "com.ss.android.ugc.trill",
        "com.twitter.android", "com.slack", "com.microsoft.teams",
    )
    private val mailPkgs = setOf(
        "com.google.android.gm", "com.microsoft.office.outlook", "com.yahoo.mobile.client.android.mail",
        "ch.protonmail.android", "com.samsung.android.email.provider",
    )
    private val clockPkgs = setOf(
        "com.google.android.deskclock", "com.android.deskclock", "com.sec.android.app.clockpackage",
        "com.oneplus.deskclock", "com.coloros.alarmclock", "com.miui.clock",
    )
    private val navPkgs = setOf("com.google.android.apps.maps", "com.waze", "com.here.app.maps", "net.osmand")

    private val answerWords = listOf(
        "answer", "accept", "pick up", "trả lời", "nghe máy", "接听", "接聽", "应答", "応答", "받기", "수락",
        "responder", "contestar", "aceptar", "répondre", "décrocher", "annehmen", "antworten", "atender", "aceitar",
        "принять", "ответить", "قبول", "उत्तर", "जवाब", "jawab", "angkat", "terima", "รับ", "cevapla", "kabul",
        "rispondi", "accetta", "opnemen", "beantwoorden", "odbierz", "przyjmij", "прийняти", "відповісти",
        "svara", "přijmout", "απάντηση", "răspunde", "fogadás", "ענה", "پاسخ",
    )
    private val declineWords = listOf(
        "decline", "reject", "dismiss", "hang up", "end call", "ignore", "từ chối", "kết thúc", "tắt máy",
        "拒接", "拒绝", "挂断", "拒否", "終了", "거절", "끊기", "rechazar", "colgar", "rejeter", "refuser", "raccrocher",
        "ablehnen", "auflegen", "recusar", "rejeitar", "desligar", "отклонить", "сбросить", "завершить",
        "رفض", "إنهاء", "अस्वीकार", "काटें", "tolak", "tutup", "ปฏิเสธ", "วางสาย", "reddet", "kapat", "rifiuta",
        "chiudi", "weigeren", "ophangen", "odrzuć", "rozłącz", "відхилити", "avvisa", "lägg på", "odmítnout",
        "zavěsit", "απόρριψη", "respinge", "elutasítás", "דחה",
    )

    /** Kinds that stay while their notification exists (picked up again when the Island starts). */
    fun isOngoingKind(k: IslandKind): Boolean =
        k == IslandKind.CALL_INCOMING || k == IslandKind.CALL_ONGOING || k == IslandKind.NAVIGATION ||
            k == IslandKind.DOWNLOAD || k == IslandKind.TIMER

    private fun clean(c: CharSequence?): String = c?.toString()?.trim().orEmpty()

    fun map(context: Context, sbn: StatusBarNotification): IslandEvent? {
        val s = IslandRuntime.settings
        val pkg = sbn.packageName ?: return null
        if (pkg == context.packageName) return null
        val n = sbn.notification ?: return null
        val ex = n.extras ?: return null
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return null
        if (ex.getString(Notification.EXTRA_TEMPLATE).orEmpty().endsWith("MediaStyle")) return null

        val cat = n.category.orEmpty()
        val ongoing = (n.flags and Notification.FLAG_ONGOING_EVENT) != 0
        val title = clean(ex.getCharSequence(Notification.EXTRA_TITLE))
        val text = clean(ex.getCharSequence(Notification.EXTRA_TEXT) ?: ex.getCharSequence(Notification.EXTRA_BIG_TEXT))
        val sub = clean(ex.getCharSequence(Notification.EXTRA_SUB_TEXT))
        val app = appLabel(context, pkg, ex)
        val accent = IslandPalette.appAccent(pkg)
        val pi = n.contentIntent
        val open: (() -> Unit)? = if (pi == null) null else ({
            try {
                pi.send()
            } catch (_: Throwable) {
            }
        })
        val showChrono = ex.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER, false)
        val countDown = ex.getBoolean("android.chronometerCountDown", false)
        val clock = if (showChrono) ClockSpec(n.`when`, countDown) else null
        val progressMax = ex.getInt(Notification.EXTRA_PROGRESS_MAX, 0)
        val progress = ex.getInt(Notification.EXTRA_PROGRESS, 0)
        val indeterminate = ex.getBoolean(Notification.EXTRA_PROGRESS_INDETERMINATE, false)
        val id = "n:" + sbn.key

        // calls
        if (cat == Notification.CATEGORY_CALL) {
            if (!s.fCall) return null
            val callType = ex.getInt("android.callType", 0)
            val incoming = callType == 1 || (callType == 0 && !ongoing)
            val name = title.ifEmpty { app }
            return if (incoming) {
                IslandEvent(
                    id = id, kind = IslandKind.CALL_INCOMING, title = name, subtitle = L10n.t("incoming_call"),
                    label = app, accent = accent, actions = callActions(n), onOpen = open,
                )
            } else {
                IslandEvent(
                    id = id, kind = IslandKind.CALL_ONGOING, title = name, subtitle = L10n.t("on_call"),
                    clock = clock, label = app, accent = accent, onOpen = open,
                )
            }
        }

        // navigation (text comes from the maps app's own notification)
        if (cat == "navigation" || (pkg in navPkgs && ongoing)) {
            if (!s.fNav) return null
            if (title.isEmpty() && text.isEmpty()) return null
            return IslandEvent(
                id = id, kind = IslandKind.NAVIGATION, title = title.ifEmpty { text },
                subtitle = if (title.isEmpty()) sub else text,
                value = if (title.isNotEmpty() && text.isNotEmpty() && sub.isNotEmpty()) sub else null,
                label = app, onOpen = open,
            )
        }

        // downloads / any determinate progress
        if (progressMax > 0 && !indeterminate) {
            if (!s.fDownload) return null
            val p = (progress.toFloat() / progressMax.toFloat()).coerceIn(0f, 1f)
            return IslandEvent(
                id = id, kind = IslandKind.DOWNLOAD, title = title.ifEmpty { L10n.t("downloading") },
                subtitle = text.ifEmpty { L10n.t("downloading") }, value = (p * 100f).toInt().toString() + "%",
                progress = p, label = app, onOpen = open,
            )
        }

        // timers / alarms / stopwatch
        if (cat == "alarm" || cat == "stopwatch" || pkg in clockPkgs) {
            if (!s.fTimer) return null
            if (title.isEmpty() && text.isEmpty() && clock == null) return null
            return IslandEvent(
                id = id, kind = IslandKind.TIMER, title = title.ifEmpty { L10n.t("timer") }, subtitle = text,
                value = if (clock == null) text.ifEmpty { null } else null, clock = clock, label = app, onOpen = open,
            )
        }

        if (ongoing) return null

        // messages, e-mail, everything else
        if (!s.fNotif) return null
        if (title.isEmpty() && text.isEmpty()) return null
        val kind = when {
            cat == Notification.CATEGORY_MESSAGE || pkg in chatPkgs -> IslandKind.MESSAGE
            cat == Notification.CATEGORY_EMAIL || pkg in mailPkgs -> IslandKind.MAIL
            else -> IslandKind.NOTIFICATION
        }
        val shownTitle: String
        val shownText: String
        if (s.hideContent) {
            shownTitle = app
            shownText = when (kind) {
                IslandKind.MESSAGE -> L10n.t("new_message")
                IslandKind.MAIL -> L10n.t("new_email")
                else -> L10n.t("notification")
            }
        } else {
            shownTitle = title.ifEmpty { app }
            shownText = text.ifEmpty { sub }
        }
        return IslandEvent(
            id = id + ":" + sbn.postTime, kind = kind, title = shownTitle, subtitle = shownText,
            ttlMs = 6000L, label = app, accent = accent, onOpen = open,
        )
    }

    private fun appLabel(context: Context, pkg: String, ex: Bundle): String {
        val pm = context.packageManager
        try {
            val info = BundleCompat.getParcelable(ex, "android.appInfo", ApplicationInfo::class.java)
            if (info != null) return pm.getApplicationLabel(info).toString()
        } catch (_: Throwable) {
        }
        try {
            return pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (_: Throwable) {
        }
        return pkg.substringAfterLast('.')
    }

    /** Only buttons whose label clearly means answer / decline are offered; otherwise tapping opens the call screen. */
    private fun callActions(n: Notification): List<IslandAction> {
        val acts = n.actions ?: return emptyList()
        val out = ArrayList<IslandAction>()
        for (a in acts) {
            val label = a.title?.toString()?.lowercase().orEmpty()
            val pi = a.actionIntent ?: continue
            val kind = when {
                declineWords.any { label.contains(it) } -> ActionKind.DECLINE
                answerWords.any { label.contains(it) } -> ActionKind.ANSWER
                else -> null
            } ?: continue
            out.add(
                IslandAction(kind) {
                    try {
                        pi.send()
                    } catch (_: Throwable) {
                    }
                },
            )
        }
        return out.sortedBy { if (it.kind == ActionKind.DECLINE) 0 else 1 }
    }
}
