package com.godly.island.i18n

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

data class LangInfo(
    val code: String,
    val native: String,
    val english: String,
    val flag: String,
    val rtl: Boolean,
)

/**
 * In-app language (default English). Strings live in assets/lang/<code>.json; a missing key
 * falls back to English. Switching is instant: the table is Compose state.
 */
object L10n {
    var languages: List<LangInfo> = emptyList()
        private set

    var code by mutableStateOf("en")
        private set

    private var table by mutableStateOf<Map<String, String>>(emptyMap())
    private var fallback: Map<String, String> = emptyMap()

    val rtl: Boolean get() = languages.firstOrNull { it.code == code }?.rtl == true

    fun init(context: Context) {
        if (languages.isNotEmpty()) return
        val app = context.applicationContext
        languages = parseIndex(app)
        fallback = loadMap(app, "en")
        val saved = prefs(app).getString("lang", "en") ?: "en"
        apply(app, if (languages.any { it.code == saved }) saved else "en")
    }

    fun set(context: Context, newCode: String) {
        val app = context.applicationContext
        apply(app, newCode)
        prefs(app).edit().putString("lang", newCode).apply()
    }

    fun t(key: String): String = table[key] ?: fallback[key] ?: key

    private fun apply(app: Context, newCode: String) {
        table = if (newCode == "en") fallback else loadMap(app, newCode)
        code = newCode
    }

    private fun prefs(app: Context) = app.getSharedPreferences("godly_island_lang", Context.MODE_PRIVATE)

    private fun loadMap(app: Context, c: String): Map<String, String> {
        return try {
            val text = app.assets.open("lang/$c.json").bufferedReader().use { it.readText() }
            val o = JSONObject(text)
            val m = HashMap<String, String>()
            val keys = o.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                m[k] = o.getString(k)
            }
            m
        } catch (t: Throwable) {
            emptyMap()
        }
    }

    private fun parseIndex(app: Context): List<LangInfo> {
        return try {
            val text = app.assets.open("lang/index.json").bufferedReader().use { it.readText() }
            val a = JSONArray(text)
            val out = ArrayList<LangInfo>()
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(
                    LangInfo(
                        o.getString("code"),
                        o.getString("native"),
                        o.getString("english"),
                        o.getString("flag"),
                        o.optBoolean("rtl", false),
                    ),
                )
            }
            out
        } catch (t: Throwable) {
            listOf(LangInfo("en", "English", "English", "\uD83C\uDDFA\uD83C\uDDF8", false))
        }
    }
}

/** Translated string for [key]; recomposes when the language changes. */
@Composable
fun tr(key: String): String = L10n.t(key)
