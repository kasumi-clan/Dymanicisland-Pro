package com.godly.island.island

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

/** Start / stop the real Island, permission shortcuts, and the Settings preview helper. */
object IslandLauncher {
    fun hasOverlayPermission(context: Context): Boolean = Settings.canDrawOverlays(context)

    fun hasNotificationAccess(context: Context): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)

    /** Opens the system screen where the user grants "Display over other apps". */
    fun openOverlaySettings(context: Context) {
        val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + context.packageName))
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(i)
    }

    /** Opens the system screen where the user grants notification access. */
    fun openNotificationAccess(context: Context) {
        val i = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(i)
    }

    /** Returns false (and opens the permission screen) when the overlay permission is missing. */
    fun start(context: Context): Boolean {
        if (!hasOverlayPermission(context)) {
            openOverlaySettings(context)
            return false
        }
        IslandRuntime.update(context) { it.copy(enabled = true) }
        ContextCompat.startForegroundService(context, Intent(context, GodlyIslandService::class.java))
        return true
    }

    fun stop(context: Context) {
        IslandRuntime.update(context) { it.copy(enabled = false) }
        context.stopService(Intent(context, GodlyIslandService::class.java))
    }
}

/** Shows the idle pill on the REAL Island while Settings sliders move. */
object IslandPreviewControl {
    fun showIdle() {
        IslandEventManager.clearSimulated()
        IslandStateManager.previewShape = IslandShape.MINI
    }

    fun stop() {
        IslandStateManager.previewShape = null
        IslandEventManager.clearSimulated()
    }
}
