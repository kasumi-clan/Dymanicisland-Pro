package com.godly.island.island

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.Dp
import com.godly.island.events.ActionKind
import com.godly.island.events.IslandKind
import kotlin.math.abs
import kotlin.math.sin

private class ParsedLayer(val path: Path, val src: IconLayer)

private val parsedCache = HashMap<List<IconLayer>, List<ParsedLayer>>()

private fun parsed(art: List<IconLayer>): List<ParsedLayer> = synchronized(parsedCache) {
    parsedCache.getOrPut(art) {
        art.map {
            val p = PathParser().parsePathString(it.d).toPath()
            p.fillType = if (it.evenOdd) PathFillType.EvenOdd else PathFillType.NonZero
            ParsedLayer(p, it)
        }
    }
}

internal fun artFor(kind: IslandKind): List<IconLayer> = when (kind) {
    IslandKind.CALL_INCOMING -> IconArt.CALL_RING
    IslandKind.CALL_ONGOING -> IconArt.CALL_LIVE
    IslandKind.MUSIC -> IconArt.MUSIC
    IslandKind.MESSAGE -> IconArt.MESSAGE
    IslandKind.MAIL -> IconArt.MAIL
    IslandKind.NOTIFICATION -> IconArt.BELL
    IslandKind.BATTERY_LOW -> IconArt.BATTERY_LOW
    IslandKind.BATTERY_FULL -> IconArt.BATTERY
    IslandKind.CHARGING -> IconArt.CHARGING
    IslandKind.TIMER -> IconArt.TIMER
    IslandKind.NAVIGATION -> IconArt.NAV
    IslandKind.BLUETOOTH -> IconArt.BLUETOOTH
    IslandKind.DOWNLOAD -> IconArt.DOWNLOAD
}

internal fun artForAction(kind: ActionKind): List<IconLayer> = when (kind) {
    ActionKind.ANSWER -> IconArt.ANSWER
    ActionKind.DECLINE -> IconArt.DECLINE
    ActionKind.PREV -> IconArt.PREV
    ActionKind.PLAY -> IconArt.PLAY
    ActionKind.PAUSE -> IconArt.PAUSE
    ActionKind.NEXT -> IconArt.NEXT
}

/** Animated transform of one role (part) of an icon. */
private class Rt {
    var dx = 0f
    var dy = 0f
    var rot = 0f
    var sc = 1f
    var a = 1f
    var px = 12f
    var py = 12f

    fun reset() {
        dx = 0f
        dy = 0f
        rot = 0f
        sc = 1f
        a = 1f
        px = 12f
        py = 12f
    }
}

private const val TAU = 6.2831855f
private const val PI_F = 3.1415927f

/** 0..1..0 hump that is active for 60% of the loop, shifted by [off]. */
private fun pulse(ph: Float, off: Float): Float {
    val v = (ph - off + 1f) % 1f
    return if (v < 0.6f) sin(v / 0.6f * PI_F) else 0f
}

/** Each function animates its own parts differently. ph = loop position 0..1. */
private fun roleXform(kind: IslandKind, role: Int, ph: Float, t: Rt) {
    t.reset()
    when (kind) {
        IslandKind.CALL_INCOMING -> {
            val e = if (ph < 0.6f) 1f - ph / 0.6f * 0.3f else 0f
            when (role) {
                0 -> t.rot = sin(ph * TAU * 5f) * 12f * e
                1 -> t.a = 0.25f + 0.75f * pulse(ph, 0f)
                2 -> t.a = 0.15f + 0.85f * pulse(ph, 0.16f)
            }
        }
        IslandKind.CALL_ONGOING -> {
            when (role) {
                1 -> { t.px = 15.6f; t.py = 8.6f; t.sc = 0.55f + 0.45f * abs(sin(ph * TAU)) }
                2 -> { t.px = 19f; t.py = 9.4f; t.sc = 0.55f + 0.45f * abs(sin(ph * TAU + 1.1f)) }
                3 -> { t.px = 22.2f; t.py = 8.6f; t.sc = 0.55f + 0.45f * abs(sin(ph * TAU + 2.2f)) }
            }
        }
        IslandKind.MUSIC -> {
            t.dy = sin(ph * TAU) * 0.55f
            t.sc = 1f + 0.04f * sin(ph * TAU * 2f)
        }
        IslandKind.MESSAGE -> {
            val p = pulse(ph, 0f)
            t.sc = 1f + 0.08f * p
            t.rot = 4f * sin(ph * TAU * 3f) * p
        }
        IslandKind.MAIL -> t.dy = -0.7f * pulse(ph, 0f)
        IslandKind.NOTIFICATION -> {
            val e = if (ph < 0.55f) 1f - ph / 0.55f else 0f
            t.px = 12f
            t.py = 2.6f
            when (role) {
                1 -> t.rot = sin(ph * TAU * 4f) * 17f * e
                2 -> t.rot = -sin(ph * TAU * 4f - 0.9f) * 9f * e
            }
        }
        IslandKind.BATTERY_LOW -> if (role == 1) t.a = 0.35f + 0.65f * (0.5f + 0.5f * sin(ph * TAU))
        IslandKind.BATTERY_FULL -> t.sc = 1f + 0.05f * pulse(ph, 0f)
        IslandKind.CHARGING -> if (role == 1) {
            t.a = 0.55f + 0.45f * (0.5f + 0.5f * sin(ph * TAU))
            t.sc = 1f + 0.1f * sin(ph * TAU)
            t.px = 12.4f
            t.py = 12f
        }
        IslandKind.TIMER -> if (role == 1) {
            t.px = 12f
            t.py = 13.4f
            t.rot = ph * 360f
        }
        IslandKind.NAVIGATION -> if (role == 1) {
            t.dx = 0.9f * sin(ph * TAU)
            t.dy = -0.9f * sin(ph * TAU)
        }
        IslandKind.BLUETOOTH -> if (role == 1) t.sc = 1f + 0.07f * sin(ph * TAU)
        IslandKind.DOWNLOAD -> if (role == 1) t.dy = 1.6f * sin(ph * TAU).coerceAtLeast(0f)
    }
}

private fun DrawScope.xf(dx: Float, dy: Float, rot: Float, sc: Float, px: Float, py: Float, block: DrawScope.() -> Unit) {
    val pivot = Offset(px, py)
    translate(dx, dy) {
        rotate(rot, pivot) {
            scale(sc, sc, pivot) { block() }
        }
    }
}

private fun DrawScope.paintLayer(l: ParsedLayer, tint: Color, brush: Brush, alphaMul: Float) {
    val src = l.src
    val a = (src.alpha * alphaMul).coerceIn(0f, 1f)
    val c = tint.copy(alpha = (tint.alpha * a).coerceIn(0f, 1f))
    val draw: DrawScope.() -> Unit = {
        if (src.fill) {
            drawPath(l.path, brush, alpha = a)
        } else {
            drawPath(l.path, c, style = Stroke(width = src.width, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    }
    if (src.sc != 1f || src.tx != 0f || src.ty != 0f || src.rot != 0f) {
        xf(src.tx, src.ty, src.rot, src.sc, src.px, src.py, draw)
    } else {
        draw()
    }
}

/** Hand-drawn, per-function animated icon. */
@Composable
fun IslandIcon(
    kind: IslandKind,
    size: Dp,
    modifier: Modifier = Modifier,
    tint: Color = Color.White,
    animated: Boolean = true,
) {
    val layers = remember(kind) { parsed(artFor(kind)) }
    val brush = remember(tint) {
        Brush.verticalGradient(listOf(tint, tint.copy(alpha = tint.alpha * 0.8f)), startY = 2f, endY = 22f)
    }
    val rt = remember { Rt() }
    val phase = if (animated) {
        rememberInfiniteTransition(label = "icon").animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(IslandFx.iconPeriodMs(kind), easing = LinearEasing), RepeatMode.Restart),
            label = "iconPhase",
        )
    } else {
        null
    }
    Canvas(modifier.size(size)) {
        val k = this.size.minDimension / 24f
        val ph = phase?.value ?: 0f
        scale(k, k, Offset.Zero) {
            for (l in layers) {
                if (animated) roleXform(kind, l.src.role, ph, rt) else rt.reset()
                xf(rt.dx, rt.dy, rt.rot, rt.sc, rt.px, rt.py) { paintLayer(l, tint, brush, rt.a) }
            }
            if (animated && kind == IslandKind.BLUETOOTH) {
                drawCircle(
                    color = tint.copy(alpha = (1f - ph) * 0.5f),
                    radius = 5f + 7f * ph,
                    center = Offset(12f, 12f),
                    style = Stroke(width = 1.2f),
                )
            }
        }
    }
}

/** Static glyph for buttons (answer, decline, previous, play, pause, next). */
@Composable
fun ActionGlyph(kind: ActionKind, size: Dp, modifier: Modifier = Modifier, tint: Color = Color.White) {
    val layers = remember(kind) { parsed(artForAction(kind)) }
    val brush = remember(tint) { Brush.verticalGradient(listOf(tint, tint), startY = 0f, endY = 24f) }
    Canvas(modifier.size(size)) {
        val k = this.size.minDimension / 24f
        scale(k, k, Offset.Zero) {
            for (l in layers) paintLayer(l, tint, brush, 1f)
        }
    }
}
