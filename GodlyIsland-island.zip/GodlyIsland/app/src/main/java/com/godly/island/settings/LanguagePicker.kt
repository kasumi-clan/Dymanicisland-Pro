package com.godly.island.settings

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.godly.island.core.GodlyColors
import com.godly.island.core.GodlyFont
import com.godly.island.i18n.L10n
import com.godly.island.i18n.LangInfo
import com.godly.island.i18n.tr

/** Full-screen language list: flag + native name, with a search bar on top. */
@Composable
fun LanguagePicker(onPick: (String) -> Unit, onBack: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val current = L10n.code
    val q = query.trim().lowercase()
    val list = L10n.languages.filter {
        q.isEmpty() || it.native.lowercase().contains(q) || it.english.lowercase().contains(q) || it.code.lowercase().contains(q)
    }
    Column(
        Modifier
            .fillMaxSize()
            .background(GodlyColors.Ink)
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            val backCb by rememberUpdatedState(onBack)
            Box(
                Modifier
                    .size(40.dp)
                    .pointerInput(Unit) { detectTapGestures(onTap = { backCb() }) },
                contentAlignment = Alignment.Center,
            ) {
                Canvas(Modifier.size(20.dp)) {
                    val p = Path()
                    p.moveTo(size.width * 0.65f, size.height * 0.12f)
                    p.lineTo(size.width * 0.25f, size.height * 0.5f)
                    p.lineTo(size.width * 0.65f, size.height * 0.88f)
                    drawPath(p, GodlyColors.Paper, style = Stroke(2.2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
            }
            Text(tr("language"), color = GodlyColors.Paper, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
        }
        BasicTextField(
            value = query,
            onValueChange = { query = it },
            singleLine = true,
            textStyle = TextStyle(color = GodlyColors.Paper, fontSize = 16.sp, fontFamily = GodlyFont),
            cursorBrush = SolidColor(GodlyColors.Paper),
            modifier = Modifier
                .fillMaxWidth()
                .background(GodlyColors.Panel, RoundedCornerShape(16.dp))
                .padding(horizontal = 16.dp, vertical = 14.dp),
            decorationBox = { inner ->
                Box {
                    if (query.isEmpty()) {
                        Text(tr("search_language"), color = GodlyColors.Muted, fontSize = 16.sp)
                    }
                    inner()
                }
            },
        )
        if (list.isEmpty()) {
            Text(tr("no_results"), color = GodlyColors.Muted, fontSize = 14.sp)
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(list, key = { it.code }) { info ->
                LangRow(info, info.code == current) { onPick(info.code) }
            }
        }
    }
}

@Composable
private fun LangRow(info: LangInfo, selected: Boolean, onClick: () -> Unit) {
    val cb by rememberUpdatedState(onClick)
    Row(
        Modifier
            .fillMaxWidth()
            .background(if (selected) Color(0x22FFFFFF) else GodlyColors.Panel, RoundedCornerShape(16.dp))
            .pointerInput(Unit) { detectTapGestures(onTap = { cb() }) }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text(info.flag, fontSize = 26.sp)
        Column(Modifier.weight(1f)) {
            Text(info.native, color = GodlyColors.Paper, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            if (info.english != info.native) {
                Text(info.english, color = GodlyColors.Muted, fontSize = 12.sp)
            }
        }
        if (selected) {
            Canvas(Modifier.size(20.dp)) {
                val p = Path()
                p.moveTo(size.width * 0.12f, size.height * 0.54f)
                p.lineTo(size.width * 0.4f, size.height * 0.8f)
                p.lineTo(size.width * 0.9f, size.height * 0.22f)
                drawPath(p, GodlyColors.Ok, style = Stroke(2.4.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
        }
    }
}
