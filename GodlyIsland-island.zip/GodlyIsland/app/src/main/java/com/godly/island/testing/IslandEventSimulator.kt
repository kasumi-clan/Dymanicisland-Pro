package com.godly.island.testing

import android.os.SystemClock
import com.godly.island.events.ActionKind
import com.godly.island.events.ClockSpec
import com.godly.island.events.IslandAction
import com.godly.island.events.IslandEvent
import com.godly.island.events.IslandKind
import com.godly.island.events.ProgressAnchor
import com.godly.island.i18n.L10n

/**
 * Produces sample events for Test only. They are plain IslandEvent objects (simulated = true) shown by
 * the in-app Island; nothing here touches NotificationManager, Telecom, MediaSession or any real service.
 */
object IslandEventSimulator {
    fun sample(kind: IslandKind): IslandEvent {
        val now = System.currentTimeMillis()
        return when (kind) {
            IslandKind.CALL_INCOMING -> IslandEvent(
                id = "sim-call-in", kind = kind, title = "Alex Morgan", subtitle = L10n.t("incoming_call"),
                simulated = true,
                actions = listOf(IslandAction(ActionKind.DECLINE) {}, IslandAction(ActionKind.ANSWER) {}),
            )
            IslandKind.CALL_ONGOING -> IslandEvent(
                id = "sim-call-on", kind = kind, title = "Alex Morgan", subtitle = L10n.t("on_call"),
                simulated = true, clock = ClockSpec(now - 134_000L, false),
            )
            IslandKind.MUSIC -> IslandEvent(
                id = "sim-music", kind = kind, title = "Midnight Drive", subtitle = "Nova", simulated = true,
                label = "Music", anchor = ProgressAnchor(70_000L, 210_000L, 1f, SystemClock.elapsedRealtime()),
                actions = listOf(
                    IslandAction(ActionKind.PREV) {},
                    IslandAction(ActionKind.PAUSE) {},
                    IslandAction(ActionKind.NEXT) {},
                ),
            )
            IslandKind.MESSAGE -> IslandEvent(
                id = "sim-msg", kind = kind, title = "Sam", subtitle = "Hey, are you free tonight?",
                simulated = true, label = "Messages",
            )
            IslandKind.MAIL -> IslandEvent(
                id = "sim-mail", kind = kind, title = "Orders", subtitle = "Your package has shipped",
                simulated = true, label = "Mail",
            )
            IslandKind.NOTIFICATION -> IslandEvent(
                id = "sim-notif", kind = kind, title = "Calendar", subtitle = "Team sync starts in 10 minutes",
                simulated = true, label = "Calendar",
            )
            IslandKind.BATTERY_LOW -> IslandEvent(
                id = "sim-batt-low", kind = kind, title = L10n.t("battery_low"), subtitle = L10n.t("plug_in"),
                value = "15%", progress = 0.15f, simulated = true,
            )
            IslandKind.BATTERY_FULL -> IslandEvent(
                id = "sim-batt-full", kind = kind, title = L10n.t("battery_full"), subtitle = L10n.t("can_unplug"),
                value = "100%", progress = 1f, simulated = true,
            )
            IslandKind.CHARGING -> IslandEvent(
                id = "sim-charge", kind = kind, title = L10n.t("charging"), subtitle = L10n.t("plug_wireless"),
                value = "68%", progress = 0.68f, simulated = true,
            )
            IslandKind.TIMER -> IslandEvent(
                id = "sim-timer", kind = kind, title = L10n.t("timer"), subtitle = "", simulated = true,
                clock = ClockSpec(now + 272_000L, true),
            )
            IslandKind.NAVIGATION -> IslandEvent(
                id = "sim-nav", kind = kind, title = "Turn left in 200 m", subtitle = "Main Street • 12 min",
                value = "200 m", simulated = true, label = "Maps",
            )
            IslandKind.BLUETOOTH -> IslandEvent(
                id = "sim-bt", kind = kind, title = "Buds Pro", subtitle = L10n.t("connected"), simulated = true,
            )
            IslandKind.DOWNLOAD -> IslandEvent(
                id = "sim-dl", kind = kind, title = "Photos.zip", subtitle = L10n.t("downloading"),
                value = "64%", progress = 0.64f, simulated = true,
            )
        }
    }

    /** Two at once: a timer pill and a music circle. */
    fun dualSample(): List<IslandEvent> = listOf(sample(IslandKind.TIMER), sample(IslandKind.MUSIC))
}
