package com.godly.island.testing

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import com.godly.island.R
import kotlin.math.abs
import kotlin.math.sin

private fun frac(v: Float): Float = ((v % 1f) + 1f) % 1f

/**
 * The Test background: the supplied sphere image, slowly breathing and drifting, with a pulsing glow
 * and a few floating lights. Everything is read in draw / layer lambdas, so it never recomposes.
 */
@Composable
fun AnimatedBackdrop(modifier: Modifier = Modifier) {
    val d = LocalDensity.current.density
    val t = rememberInfiniteTransition(label = "backdrop")
    val zoom = t.animateFloat(
        1.12f, 1.26f,
        infiniteRepeatable(tween(16000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "zoom",
    )
    val dx = t.animateFloat(
        -14f, 14f,
        infiniteRepeatable(tween(21000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "dx",
    )
    val dy = t.animateFloat(
        -10f, 10f,
        infiniteRepeatable(tween(17000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "dy",
    )
    val pulse = t.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(6000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse",
    )
    val flow = t.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(30000, easing = LinearEasing), RepeatMode.Restart), label = "flow",
    )
    val seeds = remember {
        Array(18) { i -> floatArrayOf(frac(sin(i * 12.9898f) * 43758.547f), frac(sin(i * 78.233f) * 12345.678f)) }
    }

    Box(modifier.fillMaxSize().background(Color(0xFF04010C))) {
        Image(
            painter = painterResource(R.drawable.test_bg),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = zoom.value
                    scaleY = zoom.value
                    translationX = dx.value * d
                    translationY = dy.value * d
                },
        )
        Box(
            Modifier
                .fillMaxSize()
                .drawBehind {
                    val w = size.width
                    val h = size.height
                    val p = pulse.value
                    val f = flow.value
                    val ang = f * 6.2831855f
                    drawCircle(
                        brush = Brush.radialGradient(
                            listOf(Color(0xFFFF4FA3).copy(alpha = 0.16f + 0.18f * p), Color.Transparent),
                            center = Offset(w * 0.5f + sin(ang) * w * 0.05f, h * 0.68f),
                            radius = minOf(w, h) * (0.55f + 0.12f * p),
                        ),
                        radius = minOf(w, h) * 0.8f,
                        center = Offset(w * 0.5f + sin(ang) * w * 0.05f, h * 0.68f),
                        blendMode = BlendMode.Plus,
                    )
                    drawCircle(
                        brush = Brush.radialGradient(
                            listOf(Color(0xFF5A3DFF).copy(alpha = 0.20f * (1f - p * 0.5f)), Color.Transparent),
                            center = Offset(w * 0.25f, h * 0.28f),
                            radius = minOf(w, h) * 0.5f,
                        ),
                        radius = minOf(w, h) * 0.6f,
                        center = Offset(w * 0.25f, h * 0.28f),
                        blendMode = BlendMode.Plus,
                    )
                    for (i in seeds.indices) {
                        val s = seeds[i]
                        val y = frac(s[1] - f * (0.6f + (i % 5) * 0.12f))
                        val x = s[0] + 0.02f * sin(ang * (1 + i % 3) + i)
                        val a = 0.12f + 0.38f * abs(sin(ang + i))
                        drawCircle(
                            Color.White.copy(alpha = a),
                            radius = (1.2f + (i % 4) * 0.8f) * d,
                            center = Offset(x * w, y * h),
                        )
                    }
                },
        )
    }
}
