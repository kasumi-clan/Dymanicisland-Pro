package com.godly.island.island

import android.graphics.Bitmap
import android.os.SystemClock
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.godly.island.events.ActionKind
import com.godly.island.events.IslandEvent
import com.godly.island.events.ProgressAnchor
import kotlin.math.abs
import kotlin.math.sin
import kotlinx.coroutines.delay

/** Glossy round bead behind an icon (frosted white on the colour style, accent gradient on the black style). */
@Composable
fun Bead(accent: IslandAccent, black: Boolean, sizeDp: Float, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(
        modifier
            .size(sizeDp.dp)
            .drawBehind {
                val r = size.minDimension / 2f
                if (black) {
                    drawCircle(Brush.linearGradient(listOf(accent.a, accent.b), Offset.Zero, Offset(size.width, size.height)))
                } else {
                    drawCircle(Color.White.copy(alpha = 0.20f))
                }
                drawCircle(
                    Brush.radialGradient(
                        listOf(Color.White.copy(alpha = if (black) 0.34f else 0.30f), Color.Transparent),
                        center = Offset(r, r * 0.5f),
                        radius = r * 1.1f,
                    ),
                )
                val sw = 1.dp.toPx()
                drawCircle(Color.White.copy(alpha = 0.38f), radius = r - sw / 2f, style = Stroke(sw))
            },
        contentAlignment = Alignment.Center,
    ) { content() }
}

/** Four bouncing bars. Only animates while [playing]. */
@Composable
fun EqBars(color: Color, playing: Boolean, modifier: Modifier = Modifier) {
    val phase = if (playing) {
        rememberInfiniteTransition(label = "eq").animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(1100, easing = LinearEasing), RepeatMode.Restart),
            label = "eqPhase",
        )
    } else {
        null
    }
    Canvas(modifier) {
        val n = 4
        val gap = size.width * 0.14f
        val bw = (size.width - gap * (n - 1)) / n
        val ph = phase?.value ?: 0f
        for (i in 0 until n) {
            val v = if (playing) 0.3f + 0.7f * abs(sin((ph * 2f + i * 0.31f) * 3.1415927f)) else 0.25f
            val bh = size.height * v
            drawRoundRect(
                color = color,
                topLeft = Offset(i * (bw + gap), size.height - bh),
                size = Size(bw, bh),
                cornerRadius = CornerRadius(bw / 2f),
            )
        }
    }
}

/** Album art (or a drawn disc) that spins while playing. */
@Composable
fun Disc(art: Bitmap?, accent: IslandAccent, playing: Boolean, sizeDp: Float, modifier: Modifier = Modifier) {
    val spin = if (playing) {
        rememberInfiniteTransition(label = "disc").animateFloat(
            initialValue = 0f,
            targetValue = 360f,
            animationSpec = infiniteRepeatable(tween(8000, easing = LinearEasing), RepeatMode.Restart),
            label = "discSpin",
        )
    } else {
        null
    }
    Box(modifier.size(sizeDp.dp), contentAlignment = Alignment.Center) {
        val spinMod = Modifier
            .fillMaxSize()
            .graphicsLayer { rotationZ = spin?.value ?: 0f }
        if (art != null) {
            val img = remember(art) { art.asImageBitmap() }
            Image(img, null, spinMod.clip(CircleShape), contentScale = ContentScale.Crop)
        } else {
            Canvas(spinMod) {
                val r = size.minDimension / 2f
                drawCircle(Brush.linearGradient(listOf(accent.a, accent.b), Offset.Zero, Offset(size.width, size.height)))
                for (k in 1..3) {
                    drawCircle(Color.White.copy(alpha = 0.16f), radius = r * (0.38f + k * 0.15f), style = Stroke(1.dp.toPx()))
                }
                drawArc(Color.White.copy(alpha = 0.35f), 200f, 70f, false, Offset(r * 0.18f, r * 0.18f), Size(r * 1.64f, r * 1.64f), style = Stroke(2.dp.toPx(), cap = StrokeCap.Round))
            }
        }
        Box(
            Modifier
                .size((sizeDp * 0.2f).dp)
                .background(Color.Black.copy(alpha = 0.85f), CircleShape),
        )
    }
}

/** Thin progress ring around a round body. */
fun DrawScope.drawRing(progress: Float, color: Color, widthPx: Float) {
    val p = progress.coerceIn(0f, 1f)
    val inset = widthPx / 2f
    val sz = Size(size.width - widthPx, size.height - widthPx)
    drawArc(Color.White.copy(alpha = 0.22f), 0f, 360f, false, Offset(inset, inset), sz, style = Stroke(widthPx))
    drawArc(color, -90f, 360f * p, false, Offset(inset, inset), sz, style = Stroke(widthPx, cap = StrokeCap.Round))
}

/** Text that scrolls sideways (marquee) only when it does not fit; otherwise stays still. */
@Composable
fun MarqueeText(text: String, style: TextStyle, modifier: Modifier = Modifier) {
    var boxW by remember { mutableIntStateOf(0) }
    var textW by remember(text) { mutableIntStateOf(0) }
    val offset = remember(text) { Animatable(0f) }
    LaunchedEffect(text, textW, boxW) {
        offset.snapTo(0f)
        if (boxW > 0 && textW > boxW + 2) {
            val dist = (textW - boxW).toFloat()
            delay(1200)
            while (true) {
                offset.animateTo(-dist, tween((dist * 14f).toInt().coerceIn(900, 9000), easing = LinearEasing))
                delay(900)
                offset.snapTo(0f)
                delay(1200)
            }
        }
    }
    Box(modifier.clipToBounds().onSizeChanged { boxW = it.width }) {
        Text(
            text = text,
            style = style,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Clip,
            modifier = Modifier
                .wrapContentWidth(align = Alignment.Start, unbounded = true)
                .onSizeChanged { textW = it.width }
                .graphicsLayer { translationX = offset.value },
        )
    }
}

/** Round button with a drawn glyph. Handles its own taps so it does not trigger the Island gestures. */
@Composable
fun ActionButton(kind: ActionKind, sizeDp: Float, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val bg = when (kind) {
        ActionKind.ANSWER -> Color(0xFF24C777)
        ActionKind.DECLINE -> Color(0xFFFF4D4D)
        else -> Color.White.copy(alpha = 0.18f)
    }
    Box(
        modifier
            .size(sizeDp.dp)
            .background(bg, CircleShape)
            .pointerInput(Unit) { detectTapGestures(onTap = { onClick() }) },
        contentAlignment = Alignment.Center,
    ) {
        ActionGlyph(kind, (sizeDp * 0.52f).dp)
    }
}

private fun two(n: Long) = if (n < 10) "0$n" else n.toString()

fun formatClock(ms: Long): String {
    val s = (ms / 1000L).coerceAtLeast(0L)
    val h = s / 3600L
    val m = (s % 3600L) / 60L
    val sec = s % 60L
    return if (h > 0) "$h:${two(m)}:${two(sec)}" else "${two(m)}:${two(sec)}"
}

/** The value text of an event; a live clock ticks once per second and only while it is on screen. */
@Composable
fun liveValue(ev: IslandEvent): String? {
    val clock = ev.clock ?: return ev.value
    val text by produceState(initialValue = "", clock) {
        while (true) {
            val now = System.currentTimeMillis()
            value = formatClock(if (clock.countDown) clock.baseMs - now else now - clock.baseMs)
            delay(1000L - (now % 1000L))
        }
    }
    return text
}

private fun progressOf(a: ProgressAnchor, playing: Boolean): Float? {
    if (a.durMs <= 0L) return null
    val pos = if (playing) a.posMs + ((SystemClock.elapsedRealtime() - a.atElapsed) * a.speed).toLong() else a.posMs
    return (pos.toFloat() / a.durMs.toFloat()).coerceIn(0f, 1f)
}

/** Progress 0..1 of an event; follows the playback position once per second while playing. */
@Composable
fun liveProgress(ev: IslandEvent): Float? {
    val a = ev.anchor ?: return ev.progress
    val playing = ev.playing
    val p by produceState<Float?>(initialValue = progressOf(a, playing), a, playing) {
        while (true) {
            value = progressOf(a, playing)
            if (!playing) break
            delay(1000)
        }
    }
    return p
}

/** Slim progress bar that glides between the once-per-second updates (drawn in the draw phase: no recomposition). */
@Composable
fun GlideBar(progress: Float, heightDp: Float, track: Color, fill: Brush, modifier: Modifier = Modifier) {
    val p = animateFloatAsState(progress.coerceIn(0f, 1f), tween(900, easing = LinearEasing), label = "bar")
    Box(
        modifier
            .fillMaxWidth()
            .height(heightDp.dp)
            .clip(CircleShape)
            .drawBehind {
                drawRect(track)
                drawRect(fill, size = Size(size.width * p.value, size.height))
            },
    )
}
