package com.godly.island.island

import com.godly.island.events.IslandKind

/** Per-function effect recipes (not one effect for everything). */
object IslandFx {
    enum class Axis { NONE, X, Y, BOTH }

    /** Direction of the motion blur while the content appears. */
    fun blurAxis(kind: IslandKind): Axis = when (kind) {
        IslandKind.MESSAGE, IslandKind.NOTIFICATION, IslandKind.MAIL,
        IslandKind.NAVIGATION, IslandKind.MUSIC -> Axis.X
        IslandKind.CHARGING, IslandKind.DOWNLOAD, IslandKind.BATTERY_FULL -> Axis.Y
        else -> Axis.BOTH
    }

    /** Peak sideways shake in dp when the event appears (0 = none). */
    fun shakeDp(kind: IslandKind): Float = when (kind) {
        IslandKind.BATTERY_LOW -> 7f
        IslandKind.CALL_INCOMING -> 6f
        IslandKind.MESSAGE -> 3.5f
        IslandKind.NOTIFICATION -> 3f
        IslandKind.MAIL -> 3f
        IslandKind.BLUETOOTH -> 2.5f
        IslandKind.TIMER -> 2f
        else -> 0f
    }

    /** The ringing call keeps shaking in bursts while it rings. */
    fun repeatsShake(kind: IslandKind): Boolean = kind == IslandKind.CALL_INCOMING

    /** Brief brightness flash of the body when the event appears. */
    fun flashes(kind: IslandKind): Boolean = when (kind) {
        IslandKind.BATTERY_LOW, IslandKind.CHARGING, IslandKind.BATTERY_FULL,
        IslandKind.BLUETOOTH, IslandKind.TIMER -> true
        else -> false
    }

    /** Length (ms) of one loop of the icon animation. */
    fun iconPeriodMs(kind: IslandKind): Int = when (kind) {
        IslandKind.CALL_INCOMING -> 1500
        IslandKind.CALL_ONGOING -> 900
        IslandKind.MUSIC -> 2400
        IslandKind.MESSAGE -> 2600
        IslandKind.MAIL -> 2600
        IslandKind.NOTIFICATION -> 2400
        IslandKind.BATTERY_LOW -> 1400
        IslandKind.BATTERY_FULL -> 2400
        IslandKind.CHARGING -> 1600
        IslandKind.TIMER -> 4000
        IslandKind.NAVIGATION -> 1600
        IslandKind.BLUETOOTH -> 1800
        IslandKind.DOWNLOAD -> 1200
    }
}
