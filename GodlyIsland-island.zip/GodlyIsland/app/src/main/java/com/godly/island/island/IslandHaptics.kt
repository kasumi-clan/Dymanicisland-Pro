package com.godly.island.island

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import com.godly.island.events.IslandKind

/** Short vibration for the Island's own events (battery, charging, Bluetooth) and for Test Mode. */
object IslandHaptics {
    fun play(context: Context, kind: IslandKind, force: Boolean) {
        if (!IslandRuntime.settings.haptics) return
        val own = kind == IslandKind.CHARGING || kind == IslandKind.BATTERY_LOW ||
            kind == IslandKind.BATTERY_FULL || kind == IslandKind.BLUETOOTH
        if (!own && !force) return
        try {
            val v = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
            if (!v.hasVibrator()) return
            val effect = when (kind) {
                IslandKind.BATTERY_LOW -> VibrationEffect.createWaveform(longArrayOf(0, 60, 70, 90), -1)
                IslandKind.CHARGING, IslandKind.BLUETOOTH, IslandKind.BATTERY_FULL ->
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        VibrationEffect.createPredefined(VibrationEffect.EFFECT_DOUBLE_CLICK)
                    } else {
                        VibrationEffect.createOneShot(40, VibrationEffect.DEFAULT_AMPLITUDE)
                    }
                else ->
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK)
                    } else {
                        VibrationEffect.createOneShot(25, VibrationEffect.DEFAULT_AMPLITUDE)
                    }
            }
            v.vibrate(effect)
        } catch (_: Throwable) {
        }
    }
}
