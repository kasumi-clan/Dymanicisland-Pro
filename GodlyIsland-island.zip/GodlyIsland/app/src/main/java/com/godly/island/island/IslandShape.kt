package com.godly.island.island

/** HIDDEN shrinks to nothing, MINI is also the idle pill, DUAL = pill + circle either side of the camera. */
enum class IslandShape { HIDDEN, MINI, EXPANDED, FULL, DUAL }

/** Distance between the two bodies of the Dual Island (the camera sits in the gap). */
const val DUAL_GAP_DP = 52f

/** Transparent margin kept around the bodies inside the overlay window. */
const val WINDOW_MARGIN_DP = 4f

/** Size in dp. For DUAL, w = the pill and [circle] = the diameter of the round body. */
data class PillSpec(val w: Float, val h: Float, val circle: Float = 0f) {
    val dual: Boolean get() = circle > 0f
}

private fun maxWidth(screenWdp: Float): Float = if (screenWdp > 120f) screenWdp - 16f else 300f

fun IslandSettings.specFor(shape: IslandShape, screenWdp: Float): PillSpec {
    val maxW = maxWidth(screenWdp)
    return when (shape) {
        IslandShape.HIDDEN -> PillSpec(0f, 0f)
        IslandShape.MINI -> PillSpec(miniW.coerceAtMost(maxW), miniH)
        IslandShape.EXPANDED -> PillSpec((miniW * 2.9f).coerceIn(miniW, maxW), miniH * 1.95f)
        IslandShape.FULL -> PillSpec((miniW * 2.9f).coerceIn(miniW, maxW), miniH * 4.9f)
        IslandShape.DUAL -> {
            val pillMax = (maxW - DUAL_GAP_DP) / 2f - 4f
            PillSpec((miniW * 1.4f).coerceIn(miniW, pillMax.coerceAtLeast(miniW)), miniH, miniH)
        }
    }
}

/** Overlay window size (dp) that fits [shape] plus the spring overshoot. */
fun IslandSettings.windowSizeDp(shape: IslandShape, screenWdp: Float): Pair<Float, Float> {
    val s = specFor(shape, screenWdp)
    val hidden = shape == IslandShape.HIDDEN
    val half = if (s.dual) DUAL_GAP_DP / 2f + maxOf(s.w, s.circle) else s.w / 2f
    val baseW = if (hidden) miniW else 2f * half
    val baseH = if (hidden) miniH else s.h
    val w = (baseW * 1.08f + 2f * WINDOW_MARGIN_DP).coerceAtMost(screenWdp.coerceAtLeast(200f))
    return Pair(w, baseH * 1.08f + 2f * WINDOW_MARGIN_DP)
}
