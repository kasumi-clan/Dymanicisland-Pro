package com.godly.island.notifications

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.godly.island.island.IslandEventManager
import com.godly.island.island.IslandRuntime
import com.godly.island.media.MediaWatcher

/** Reads real notifications (messages, calls, navigation, downloads, timers) and the active music session. */
class GodlyNotificationListener : NotificationListenerService() {
    private var media: MediaWatcher? = null

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        media = MediaWatcher(this).also { it.start() }
        syncAll()
    }

    override fun onListenerDisconnected() {
        media?.stop()
        media = null
        if (instance === this) instance = null
        super.onListenerDisconnected()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null || !IslandRuntime.running) return
        val ev = NotificationMapper.map(this, sbn) ?: return
        IslandEventManager.post(ev)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        if (sbn == null) return
        IslandEventManager.removeByPrefix("n:" + sbn.key)
    }

    /** Called when the Island starts: pick up ongoing things (calls, navigation, downloads, timers, music). */
    fun syncAll() {
        if (!IslandRuntime.running) return
        media?.refresh()
        val list: Array<StatusBarNotification>? = try {
            activeNotifications
        } catch (_: Throwable) {
            null
        }
        if (list == null) return
        for (sbn in list) {
            val ev = NotificationMapper.map(this, sbn) ?: continue
            if (NotificationMapper.isOngoingKind(ev.kind)) IslandEventManager.post(ev)
        }
    }

    companion object {
        @Volatile
        var instance: GodlyNotificationListener? = null

        fun resync() {
            instance?.syncAll()
        }
    }
}
