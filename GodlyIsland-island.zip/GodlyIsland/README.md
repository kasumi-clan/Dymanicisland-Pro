# Godly Island

Dynamic Island cho Android (Kotlin + Jetpack Compose).

## Tình trạng (trung thực)

Toàn bộ code của bản 0.3.0 **chưa được biên dịch và chưa chạy trên máy thật** (môi trường soạn code không có Android SDK).
Hãy build bằng GitHub Actions (`BUILD.md`), cài APK và thử theo `docs/TEST_GUIDE.md`.

| Phần | Ghi chú |
|---|---|
| Island ở cụm camera | Đen thuần khi rảnh. Có sự kiện thì thân chuyển sang nhiều màu (kiểu Color) hoặc giữ đen (kiểu Black) |
| Nền động của Island | Shader thủ tục, trôi chậm; đã chạy thử trong WebGL, chưa thử AGSL trên Android |
| Icon | Vẽ tay bằng path, mỗi chức năng một animation riêng (`docs/design_icons.png`) |
| Hiệu ứng riêng từng chức năng | Rung, nhấp sáng, motion blur theo trục X/Y (blur cần Android 12+), icon chuyển động |
| Nhạc | Một viên + một hình tròn (đĩa xoay/ảnh album), nút trước/phát/sau thật qua MediaSession |
| Sự kiện thật | Pin, Bluetooth, thông báo/tin nhắn/email, cuộc gọi (từ thông báo của app Điện thoại), điều hướng (thông báo Maps), tải xuống, hẹn giờ/báo thức, nhạc |
| Trả lời / từ chối cuộc gọi | Chỉ hiện nút khi nhận ra chắc chắn tên nút; nếu không, chạm để mở màn hình cuộc gọi |
| Ngôn ngữ | Mặc định English, 30 ngôn ngữ có cờ + thanh tìm kiếm. Bản dịch do AI soạn, nên nhờ người bản xứ rà soát |
| Font | iCiel Samsung Sharp Sans Bold; ký tự thiếu (Trung, Nhật, Hàn, Ả Rập…) dùng font hệ thống |

## Cấu trúc

```
app/src/main/
  assets/island_material.agsl      thân Island (thủ tục, nền động)
  assets/lang/*.json               30 ngôn ngữ + index.json (cờ)
  res/font, res/drawable-nodpi     font + ảnh nền Test
  java/com/godly/island/
    island/                        IslandView, IslandIcons (animated), IslandParts, IslandFx, service, window, state/event managers
    notifications/ media/ bluetooth/ battery/   nguồn sự kiện thật
    i18n/ settings/ testing/ core/ renderer/ events/
.github/workflows/build-apk.yml    build APK (tự giải nén zip ở thư mục gốc repo)
```
