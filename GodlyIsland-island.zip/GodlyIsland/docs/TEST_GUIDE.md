# Hướng dẫn test

1. Mở app → bật Island. Lần đầu app mở trang cấp quyền hiển thị trên ứng dụng khác; bật rồi quay lại và bật lại.
2. Island đen phải nằm đúng lỗ camera. Nếu lệch: Settings → Position, kéo Horizontal / Vertical cho trùng. Ghi lại số đã chỉnh.
3. Settings → Permissions: cấp Notification access (và Bluetooth nếu muốn thấy tên tai nghe).
4. Thử thật: gửi tin nhắn cho mình, phát nhạc, cắm/rút sạc, bật hẹn giờ, gọi điện đến máy.
5. Màn Test: nền ảnh chuyển động, chạm icon để xem từng chức năng, chạm Island = mở/thu, nhấn giữ = Full, vuốt lên = thu nhỏ. Nút Test all chạy toàn bộ và báo Passed/Failed.
6. Đổi ngôn ngữ trong Settings → Language.

Báo lại: ảnh chụp Island thật (rảnh + có sự kiện), chức năng nào lỗi, chỗ nào còn lag, số Position bạn đã chỉnh.
