# Kế hoạch

| Hạng mục | Trạng thái |
|---|---|
| Island overlay, state/event/window manager | Code xong, chưa chạy máy |
| Thân Island thủ tục + nền động | Code xong; shader kiểm trong WebGL |
| Icon + animation riêng từng chức năng | Code xong |
| Sự kiện thật: pin, Bluetooth, thông báo, cuộc gọi, điều hướng, tải xuống, hẹn giờ, nhạc | Code xong, chưa thử với app thật |
| 30 ngôn ngữ + font | Code xong |
| Chưa làm | Hotspot/Wi-Fi/airplane/NFC, ghi màn hình, chế độ game, API cho app khác, tự bật khi khởi động máy |
