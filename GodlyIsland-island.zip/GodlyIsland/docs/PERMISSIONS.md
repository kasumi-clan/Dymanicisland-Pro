# Quyền

| Quyền | Để làm gì | Bật ở đâu |
|---|---|---|
| Hiển thị trên ứng dụng khác | Vẽ Island | Cài đặt → mục Permissions (app mở sẵn trang hệ thống) |
| Truy cập thông báo | Đọc thông báo, cuộc gọi, điều hướng, tải xuống, hẹn giờ và phiên nhạc | Cài đặt → Permissions |
| Bluetooth (Android 12+) | Hiện tên tai nghe khi kết nối | Cài đặt → Permissions |
| Thông báo của app (Android 13+) | Dòng "Island đang chạy"; từ chối vẫn chạy | Hộp thoại khi bật |
| Rung | Rung ngắn cho pin / Bluetooth | Tự động |

Không có server, không gửi dữ liệu ra ngoài. Nội dung thông báo chỉ được đọc trong máy để hiển thị; có thể ẩn nội dung tin nhắn trong Cài đặt.
