# Changelog

## 0.3.0
- Island rảnh = đen thuần; có sự kiện mới chuyển màu (bỏ ripple và bóng láng quét).
- Nền động trôi chậm cho thân Island; chỉ chạy khi đang có sự kiện (30 fps mở rộng, 20 fps thu gọn).
- Icon vẽ lại, mỗi chức năng một animation (tay nghe rung, chuông lắc, đồng hồ quay, mũi tên tiến, bluetooth lan sóng…).
- Hiệu ứng xuất hiện: nảy lò xo, nội dung hiện trễ, motion blur theo trục riêng từng chức năng, rung và nhấp sáng.
- Nhạc: viên + hình tròn (đĩa xoay hoặc ảnh album), màu lấy từ ảnh album, nút điều khiển thật.
- Sự kiện thật: thông báo/tin nhắn/email, cuộc gọi, điều hướng, tải xuống, hẹn giờ, nhạc, Bluetooth, pin.
- Chữ dài chạy ngang (marquee) thay vì bị cắt.
- Cài đặt gọn: ngang/cao + vị trí (khoảng chỉnh rộng hơn), kiểu Color/Black, bật tắt từng loại sự kiện, ẩn nội dung tin nhắn.
- 30 ngôn ngữ, mặc định English, có cờ và thanh tìm kiếm. Font Samsung Sharp Sans.
- Test: nền ảnh động, icon chức năng, một nút Test all.
- Bỏ: phòng thử Liquid Glass và các thanh chỉnh kính, chỉnh cỡ Expanded/Full, các dòng chú thích.
